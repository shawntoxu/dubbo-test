package auto.common.testapi;

import java.util.List;

import auto.common.testapi.param.UserParam;

/**
 * 
 * @author shawn.wang
 *  just supply a test method 
 */
public interface UserService {
	
	List<String> getUserList() ;
	
	
	Integer UpdateUser(UserParam u) ;

}
