package auto.common.testapi.param;



//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;

import java.io.Serializable;
//
///**
// * Title: BaseParam.java
// * Description: BaseParam
// *
// * @author Sisi
// *         创建时间 2014年7月14日 下午3:04:31
// */
//@Setter
//@Getter
//@NoArgsConstructor
public class BaseParam implements Serializable {

    /**
     * 当前页
     */
    private Integer pSize;

    /**
     * 每页条数，如果为0，不翻页
     */
    private Integer cPage;

}
