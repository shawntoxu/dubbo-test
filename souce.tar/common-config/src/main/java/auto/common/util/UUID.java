 package auto.common.util;
 
 import org.apache.commons.lang3.RandomUtils;
 
 public class UUID
 {
   public static String get()
   {
     return java.util.UUID.randomUUID().toString().replaceAll("-", "");
   }
 
   public static Long getLongId() {
     long time = System.currentTimeMillis();
     long returnValue = time * RandomUtils.nextInt(1, 99) + get().hashCode();
     return Long.valueOf(returnValue);
   }
 }


