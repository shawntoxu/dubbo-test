 package auto.common.util;
 
 import com.alibaba.fastjson.JSON;
 import java.util.HashMap;
 import java.util.Map;
 
 public class StringUtil
 {
   public static boolean isEmpty(String str)
   {
     if ((str == null) || (str.length() == 0) || (trim(str).equals("")) || (str.equalsIgnoreCase("null"))) {
       return true;
     }
     return false;
   }
 
   public static boolean isNotEmpty(String str)
   {
     return !isEmpty(str);
   }
 
   public static String trim(String str)
   {
     if ((str == null) || (str.trim().equals(""))) {
       return "";
     }
 
     String newStr = str.trim();
     boolean startFull = newStr.startsWith("　");
     boolean endFull = newStr.endsWith("　");
     boolean startHalf = newStr.startsWith(" ");
     boolean endHalf = newStr.endsWith(" ");
 
     while ((startFull) || (endFull) || (startHalf) || (endHalf)) {
       startFull = newStr.startsWith("　");
       endFull = newStr.endsWith("　");
 
       if (startFull) {
         if (newStr.length() == 1) {
           return "";
         }
 
         newStr = newStr.substring(1);
       }
 
       if (endFull) {
         if (newStr.length() == 1) {
           return "";
         }
 
         newStr = newStr.substring(0, newStr.length() - 1);
       }
 
       startHalf = newStr.startsWith(" ");
       endHalf = newStr.endsWith(" ");
 
       if (startHalf) {
         newStr = newStr.substring(1);
       }
 
       if (endHalf) {
         newStr = newStr.substring(0, newStr.length() - 1);
       }
     }
 
     return newStr;
   }
 
   public static boolean isLimitedLength(String str, int length)
   {
     return (isNotEmpty(str)) && (trim(str).length() < length);
   }
 
   public static String convertUnicode(String msg)
   {
     if (msg == null) {
       return "";
     }
     char[] in = msg.toCharArray();
     int off = 0;
 
     char[] out = new char[in.length];
     int outLen = 0;
     while (off < in.length) {
       char c = in[(off++)];
       if (c == '\\') {
         if (in.length > off) {
           c = in[(off++)];
         } else {
           out[(outLen++)] = '\\';
           break;
         }
         if (c == 'u') {
           int value = 0;
           if (in.length > off + 4) {
             boolean isUnicode = true;
             for (int i = 0; i < 4; i++) {
               c = in[(off++)];
               switch (c) {
               case '0':
               case '1':
               case '2':
               case '3':
               case '4':
               case '5':
               case '6':
               case '7':
               case '8':
               case '9':
                 value = (value << 4) + c - 48;
                 break;
               case 'a':
               case 'b':
               case 'c':
               case 'd':
               case 'e':
               case 'f':
                 value = (value << 4) + 10 + c - 97;
                 break;
               case 'A':
               case 'B':
               case 'C':
               case 'D':
               case 'E':
               case 'F':
                 value = (value << 4) + 10 + c - 65;
                 break;
               case ':':
               case ';':
               case '<':
               case '=':
               case '>':
               case '?':
               case '@':
               case 'G':
               case 'H':
               case 'I':
               case 'J':
               case 'K':
               case 'L':
               case 'M':
               case 'N':
               case 'O':
               case 'P':
               case 'Q':
               case 'R':
               case 'S':
               case 'T':
               case 'U':
               case 'V':
               case 'W':
               case 'X':
               case 'Y':
               case 'Z':
               case '[':
               case '\\':
               case ']':
               case '^':
               case '_':
               case '`':
               default:
                 isUnicode = false;
               }
             }
             if (isUnicode) {
               out[(outLen++)] = ((char)value);
             } else {
               off -= 4;
               out[(outLen++)] = '\\';
               out[(outLen++)] = 'u';
               out[(outLen++)] = in[(off++)];
             }
           } else {
             out[(outLen++)] = '\\';
             out[(outLen++)] = 'u';
             continue;
           }
         } else {
           switch (c) {
           case 't':
             c = '\t';
             out[(outLen++)] = c;
             break;
           case 'r':
             c = '\r';
             out[(outLen++)] = c;
             break;
           case 'n':
             c = '\n';
             out[(outLen++)] = c;
             break;
           case 'f':
             c = '\f';
             out[(outLen++)] = c;
             break;
           default:
             out[(outLen++)] = '\\';
             out[(outLen++)] = c;
             break;
           }
         }
       } else {
         out[(outLen++)] = c;
       }
     }
     return new String(out, 0, outLen);
   }
 
   public static String trimFirstAndLastChar(String source, char element)
   {
     if (isEmpty(source))
       return "";
     boolean beginIndexFlag = true;
     boolean endIndexFlag = true;
     do {
       int beginIndex = source.indexOf(element) == 0 ? 1 : 0;
       int endIndex = source.lastIndexOf(element) + 1 == source.length() ? source.lastIndexOf(element) : source.length();
       source = source.substring(beginIndex, endIndex);
       beginIndexFlag = source.indexOf(element) == 0;
       endIndexFlag = source.lastIndexOf(element) + 1 == source.length();
     }while ((beginIndexFlag) || (endIndexFlag));
     return source;
   }
 
   public static String firstToUpperCase(String str)
   {
     if (isEmpty(str)) return "";
     return str.substring(0, 1).toUpperCase() + str.substring(1);
   }
 
   public static Map<String, String> parseParamsToMap(String parmsstr)
   {
     if (isEmpty(parmsstr)) return new HashMap();
     Map paramsMap = (Map)JSON.parseObject(parmsstr, Map.class);
     return paramsMap;
   }
 }


