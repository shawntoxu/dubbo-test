 package auto.common.util;
 
 import java.io.File;
 import java.io.FileInputStream;
 import java.io.FileOutputStream;
 import java.io.IOException;
 import java.io.ObjectInputStream;
 import java.io.ObjectOutputStream;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 
 public class DumpUtil
 {
   private static Logger logger = LoggerFactory.getLogger(DumpUtil.class);
 
   public static void Object2File(Object object, String outputFile)
   {
     ObjectOutputStream oos = null;
     FileOutputStream fos = null;
     try {
       fos = new FileOutputStream(new File(outputFile));
       oos = new ObjectOutputStream(fos);
       oos.writeObject(object);
     } catch (Exception e) {
       logger.error(e.getMessage(), e);
     } finally {
       if (oos != null) {
         try {
           oos.close();
         } catch (IOException e1) {
           logger.error(e1.getMessage(), e1);
         }
       }
       if (fos != null)
         try {
           fos.close();
         } catch (IOException e2) {
           logger.error(e2.getMessage(), e2);
         }
     }
   }
 
   public static Object File2Object(String inputFile)
   {
     FileInputStream fis = null;
     ObjectInputStream ois = null;
     try {
       fis = new FileInputStream(inputFile);
       ois = new ObjectInputStream(fis);
       Object object = ois.readObject();
       return object;
     } catch (Exception e) {
       logger.error(e.getMessage(), e);
     } finally {
       if (fis != null) {
         try {
           fis.close();
         } catch (IOException e1) {
           logger.error(e1.getMessage(), e1);
         }
       }
       if (ois != null) {
         try {
           ois.close();
         } catch (IOException e2) {
           logger.error(e2.getMessage(), e2);
         }
       }
     }
     return null;
   }
 }

