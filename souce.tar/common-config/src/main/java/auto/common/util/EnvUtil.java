 package auto.common.util;
 
 import java.net.URL;
 import java.util.Properties;
 
 public class EnvUtil
 {
   private static Properties props = System.getProperties();
 
   public static String getJavaVersion()
   {
     return props.getProperty("java.version");
   }
 
   public static String getJavaVendor()
   {
     return props.getProperty("java.vendor");
   }
 
   public static String getJavaVendorUrl()
   {
     return props.getProperty("java.vendor.url");
   }
 
   public static String getJavaHome()
   {
     return props.getProperty("java.home");
   }
 
   public static String getJvmSpecVersion()
   {
     return props.getProperty("java.vm.specification.version");
   }
 
   public static String getJvmSpecVendor()
   {
     return props.getProperty("java.vm.specification.vendor");
   }
 
   public static String getJvmSpecName()
   {
     return props.getProperty("java.vm.specification.name");
   }
 
   public static String getJvmVersion()
   {
     return props.getProperty("java.vm.version");
   }
 
   public static String getJvmVendor()
   {
     return props.getProperty("java.vm.vendor");
   }
 
   public static String getJvmName()
   {
     return props.getProperty("java.vm.name");
   }
 
   public static String getJavaSpecVersion()
   {
     return props.getProperty("java.specification.version");
   }
 
   public static String getJavaSpecVender()
   {
     return props.getProperty("java.specification.vender");
   }
 
   public static String getJavaSpecName()
   {
     return props.getProperty("java.specification.name");
   }
 
   public static String getJavaClassVersion()
   {
     return props.getProperty("java.class.version");
   }
 
   public static String getJavaClassPath()
   {
     return props.getProperty("java.class.path");
   }
 
   public static String getJavaLibraryPath()
   {
     return props.getProperty("java.library.path");
   }
 
   public static String getJavaIoTempDir()
   {
     return props.getProperty("java.io.tmpdir");
   }
 
   public static String getJavaExtDir()
   {
     return props.getProperty("java.ext.dirs");
   }
 
   public static String getOsName()
   {
     return props.getProperty("os.name");
   }
 
   public static String getOsArch()
   {
     return props.getProperty("os.arch");
   }
 
   public static boolean isUnix()
   {
     return !getOsName().toLowerCase().contains("win");
   }
 
   public static String getOsVersion()
   {
     return props.getProperty("os.version");
   }
 
   public static String getFileSeparator()
   {
     return props.getProperty("file.separator");
   }
 
   public static String getPathSeparator()
   {
     return props.getProperty("path.separator");
   }
 
   public static String getLineSeparator()
   {
     return props.getProperty("line.separator");
   }
 
   public static String getUserName()
   {
     return props.getProperty("user.name");
   }
 
   public static String getUserHome()
   {
     return props.getProperty("user.home");
   }
 
   public static String getUserDir()
   {
     return props.getProperty("user.dir");
   }
 
   public static String getWorkDir()
   {
     String url = EnvUtil.class.getResource("").toString().substring(9);
     return getLibPath(url);
   }
 
   private static String getLibPath(String url) {
     if (url.contains("/lib/")) {
       url = url.substring(0, url.indexOf("/lib/"));
     }
     return url;
   }
 }

