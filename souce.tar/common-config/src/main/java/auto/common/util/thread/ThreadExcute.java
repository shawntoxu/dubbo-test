 package auto.common.util.thread;
 
 import java.util.concurrent.ExecutorService;
 import java.util.concurrent.Executors;
 
 public class ThreadExcute
 {
   private ExecutorService fixedThreadPool;
 
   public ThreadExcute(int threadCount)
   {
     this.fixedThreadPool = Executors.newFixedThreadPool(threadCount);
   }
 
   public ThreadExcute() {
     this.fixedThreadPool = Executors.newFixedThreadPool(10);
   }
 
   public void doThread(Runnable run) {
     this.fixedThreadPool.execute(run);
   }
 
   public boolean waitingTerminated() {
     System.gc();
     this.fixedThreadPool.shutdown();
 
     while (!this.fixedThreadPool.isTerminated()) {
       try {
         Thread.sleep(1L);
       } catch (InterruptedException var2) {
         var2.printStackTrace();
       }
     }
 
     return true;
   }
 
   public boolean waitingTerminated(long sleepTime) {
     System.gc();
     this.fixedThreadPool.shutdown();
 
     while (!this.fixedThreadPool.isTerminated()) {
       try {
         Thread.sleep(sleepTime);
       } catch (InterruptedException var4) {
         var4.printStackTrace();
       }
     }
 
     return true;
   }
 }

/* Location:           C:\Users\shawn.wang\Desktop\ec-netwok\依赖\common-lang-0.1-SNAPSHOT.jar
 * Qualified Name:     com.ndp.fb.util.thread.ThreadExcute
 * JD-Core Version:    0.6.2
 */
