 package auto.common.util;
 
 public class SQLUtil
 {
   public static String appendPlaceholder(int number)
   {
     StringBuilder sql = new StringBuilder();
     for (int i = 0; i < number; i++) {
       if (i + 1 < number)
         sql.append("?,");
       else {
         sql.append("?");
       }
     }
     return sql.toString();
   }
 }

