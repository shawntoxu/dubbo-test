 package auto.common.util;
 
 import java.lang.reflect.Field;
 import java.util.ArrayList;
 import java.util.Collection;
 import java.util.HashMap;
 import java.util.HashSet;
 import java.util.Iterator;
 import java.util.List;
 import java.util.Map;
 import java.util.Set;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.BeanUtils;
 
 public class ListUtil
 {
   private static Logger logger = LoggerFactory.getLogger(ListUtil.class);
 
   public static boolean isEmpty(List list)
   {
     return (list == null) || (list.size() == 0);
   }
 
   public static boolean isNotEmpty(List list) {
     return !isEmpty(list);
   }
 
   public static <T> List<List<T>> groupList(List<T> allList, int size) {
     if (isEmpty(allList)) {
       return null;
     }
 
     int totalCount = allList.size();
     int groupCount = totalCount / size;
     int last = totalCount % size;
 
     List results = new ArrayList();
 
     for (int i = 0; i < groupCount; i++) {
       List group = allList.subList(i * size, (i + 1) * size);
       results.add(group);
     }
 
     if (0 < last) {
       List group = allList.subList(groupCount * size, groupCount * size + last);
       results.add(group);
     }
 
     return results;
   }
 
   public static List removeDuplicateWithOrder(List list)
   {
     Set set = new HashSet();
     List newList = new ArrayList();
     for (Iterator iter = list.iterator(); iter.hasNext(); ) {
       Object element = iter.next();
       if (set.add(element))
         newList.add(element);
     }
     list.clear();
     list.addAll(newList);
     return list;
   }
 
   public static boolean isContain(List<String> bigList, List<String> smallList)
   {
     boolean flag = false;
     Set set = new HashSet();
     if (isNotEmpty(bigList)) {
       for (String element : bigList) {
         set.add(element);
       }
       flag = set.containsAll(smallList);
     }
     return flag;
   }
 
   public static void copy(List des, List src)
   {
     for (Iterator localIterator = src.iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
       des.add(o);
     }
   }
 
   public static <T> Map<String, T> convertToMap(List<T> list, String propertyName)
   {
     if (isEmpty(list)) return null;
     Field[] fields = list.get(0).getClass().getDeclaredFields();
     Field field = null;
     for (Field f : fields) {
       if (f.getName().equals(propertyName)) {
         f.setAccessible(true);
         field = f;
       }
     }
 
     Object map = new HashMap();
     for (Iterator localIterator = list.iterator(); localIterator.hasNext(); ) { Object t = localIterator.next();
       String key = "";
       try {
         if (field == null) {
           key = t.toString();
         } else {
           Object o = field.get(t);
           if (o == null)
             key = t.toString();
           else
             key = String.valueOf(o);
         }
       }
       catch (Exception e) {
         e.printStackTrace();
       }
       ((Map)map).put(key, t);
     }
     return (Map<String, T>) map;
   }
 
   public static <T> List<T> convertList(List src, Class<T> srcclazz) {
     List target = new ArrayList();
     Iterator localIterator;
     if (src != null) {
       for (localIterator = src.iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
         Object to = null;
         try {
           to = srcclazz.newInstance();
         } catch (Exception e) {
           logger.error(e.getMessage());
         }
         BeanUtils.copyProperties(o, to);
         target.add(to);
       }
     }
     return target;
   }
 
   public static <T> Collection<T> convertFromArray(Object[] arr) {
     Collection result = new ArrayList();
     if (arr != null) {
       for (Object o : arr) {
         result.add(o);
       }
     }
     return result;
   }
 }

