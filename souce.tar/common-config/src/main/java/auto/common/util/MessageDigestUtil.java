 package auto.common.util;
 
 import java.security.MessageDigest;
 
 public class MessageDigestUtil
 {
   public static String MD5(String s)
   {
     char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
     try {
       byte[] btInput = s.getBytes();
 
       MessageDigest mdInst = MessageDigest.getInstance("MD5");
 
       mdInst.update(btInput);
 
       byte[] md = mdInst.digest();
 
       int j = md.length;
       char[] str = new char[j * 2];
       int k = 0;
       for (byte byte0 : md) {
         str[(k++)] = hexDigits[(byte0 >>> 4 & 0xF)];
         str[(k++)] = hexDigits[(byte0 & 0xF)];
       }
       return new String(str);
     } catch (Exception e) {
       e.printStackTrace();
     }return null;
   }
 }

/* Location:           C:\Users\shawn.wang\Desktop\ec-netwok\依赖\common-lang-0.1-SNAPSHOT.jar
 * Qualified Name:     com.ndp.fb.util.MessageDigestUtil
 * JD-Core Version:    0.6.2
 */
