 package auto.common.util.thread;
 
 public abstract class CommonThread
   implements Runnable
 {
   private ICallBack callBack;
 
   public CommonThread()
   {
   }
 
   public CommonThread(ICallBack callBack)
   {
     this.callBack = callBack;
   }
 
   public ICallBack getCallBack() {
     return this.callBack;
   }
 }


