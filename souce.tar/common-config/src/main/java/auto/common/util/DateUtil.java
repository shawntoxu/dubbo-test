 package auto.common.util;
 
 import java.text.ParseException;
 import java.text.ParsePosition;
 import java.text.SimpleDateFormat;
 import java.util.Calendar;
 import java.util.Date;
 import java.util.TimeZone;
 import java.util.regex.Matcher;
 import java.util.regex.Pattern;
 import org.apache.commons.lang3.StringUtils;
 import org.joda.time.DateTime;
 import org.joda.time.tz.CachedDateTimeZone;
 
 public class DateUtil
 {
   public static final String FORMAT_ONE = "yyyy-MM-dd HH:mm:ss";
   public static final String FORMAT_TWO = "yyyy-MM-dd HH:mm";
   public static final String FORMAT_THREE = "yyyyMMdd-HHmmss";
   public static final String LONG_DATE_FORMAT = "yyyy-MM-dd";
   public static final String SHORT_DATE_FORMAT = "MM-dd";
   public static final String LONG_TIME_FORMAT = "HH:mm:ss";
   public static final String MONTG_DATE_FORMAT = "yyyy-MM";
   public static final int SUB_YEAR = 1;
   public static final int SUB_MONTH = 2;
   public static final int SUB_DAY = 5;
   public static final int SUB_HOUR = 10;
   public static final int SUB_MINUTE = 12;
   public static final int SUB_SECOND = 13;
   static final String[] dayNames = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
 
   private static final SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 
   public static Date stringtoDate(String dateStr, String format)
   {
     Date d = null;
     SimpleDateFormat formater = new SimpleDateFormat(format);
     try {
       formater.setLenient(false);
       d = formater.parse(dateStr);
     }
     catch (Exception e) {
       d = null;
     }
     return d;
   }
 
   public static Date stringtoDate(String dateStr, String format, ParsePosition pos)
   {
     Date d = null;
     SimpleDateFormat formater = new SimpleDateFormat(format);
     try {
       formater.setLenient(false);
       d = formater.parse(dateStr, pos);
     } catch (Exception e) {
       d = null;
     }
     return d;
   }
 
   public static String parserDateToStr(Date date, String format, String TimeZoneID) {
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     dateFormat.setTimeZone(TimeZone.getTimeZone(TimeZoneID));
     return dateFormat.format(date);
   }
 
   public static String dateToString(Date date, String format)
   {
     String result = "";
     SimpleDateFormat formater = new SimpleDateFormat(format);
     try {
       result = formater.format(date);
     }
     catch (Exception localException) {
     }
     return result;
   }
 
   public static String getCurrDate(String format)
   {
     return dateToString(new Date(), format);
   }
 
   public static String dateSub(int dateKind, String dateStr, int amount) {
     Date date = stringtoDate(dateStr, "yyyy-MM-dd HH:mm:ss");
     Calendar calendar = Calendar.getInstance();
     calendar.setTime(date);
     calendar.add(dateKind, amount);
     return dateToString(calendar.getTime(), "yyyy-MM-dd HH:mm:ss");
   }
 
   public static long timeSub(String firstTime, String secTime)
   {
     long first = stringtoDate(firstTime, "yyyy-MM-dd HH:mm:ss").getTime();
     long second = stringtoDate(secTime, "yyyy-MM-dd HH:mm:ss").getTime();
     return (second - first) / 1000L;
   }
 
   public static int getDaysOfMonth(String year, String month)
   {
     int days = 0;
     if ((month.equals("1")) || (month.equals("3")) || (month.equals("5")) || 
       (month
       .equals("7")) || 
       (month.equals("8")) || (month.equals("10")) || 
       (month
       .equals("12")))
     {
       days = 31;
     } else if ((month.equals("4")) || (month.equals("6")) || (month.equals("9")) || 
       (month
       .equals("11")))
     {
       days = 30;
     }
     else if (((Integer.parseInt(year) % 4 == 0) && (Integer.parseInt(year) % 100 != 0)) || 
       (Integer.parseInt(year) % 
       400 == 0))
       days = 29;
     else {
       days = 28;
     }
 
     return days;
   }
 
   public static int getDaysOfMonth(int year, int month)
   {
     Calendar calendar = Calendar.getInstance();
     calendar.set(year, month - 1, 1);
     return calendar.getActualMaximum(5);
   }
 
   public static int getToday()
   {
     Calendar calendar = Calendar.getInstance();
     return calendar.get(5);
   }
 
   public static int getToMonth()
   {
     Calendar calendar = Calendar.getInstance();
     return calendar.get(2) + 1;
   }
 
   public static int getToYear()
   {
     Calendar calendar = Calendar.getInstance();
     return calendar.get(1);
   }
 
   public static int getDay(Date date)
   {
     Calendar calendar = Calendar.getInstance();
     calendar.setTime(date);
     return calendar.get(5);
   }
 
   public static int getYear(Date date)
   {
     Calendar calendar = Calendar.getInstance();
     calendar.setTime(date);
     return calendar.get(1);
   }
 
   public static int getMonth(Date date)
   {
     Calendar calendar = Calendar.getInstance();
     calendar.setTime(date);
     return calendar.get(2) + 1;
   }
 
   public static long dayDiff(Date date1, Date date2)
   {
     return (date2.getTime() - date1.getTime()) / 86400000L;
   }
 
   public static int yearDiff(String before, String after)
   {
     Date beforeDay = stringtoDate(before, "yyyy-MM-dd");
     Date afterDay = stringtoDate(after, "yyyy-MM-dd");
     return getYear(afterDay) - getYear(beforeDay);
   }
 
   public static int yearDiffCurr(String after)
   {
     Date beforeDay = new Date();
     Date afterDay = stringtoDate(after, "yyyy-MM-dd");
     return getYear(beforeDay) - getYear(afterDay);
   }
 
   public static String getNow()
   {
     Calendar today = Calendar.getInstance();
     return dateToString(today.getTime(), "yyyy-MM-dd HH:mm:ss");
   }
 
   public static Date addDateByTypeAndOffset(Date date, int type, int offset)
   {
     Calendar time = Calendar.getInstance();
     time.setTime(date);
     time.add(type, offset);
     return time.getTime();
   }
 
   public static boolean isDate(String date)
   {
     StringBuffer reg = new StringBuffer("^((\\d{2}(([02468][048])|([13579][26]))-?((((0?");
 
     reg.append("[13578])|(1[02]))-?((0?[1-9])|([1-2][0-9])|(3[01])))");
     reg.append("|(((0?[469])|(11))-?((0?[1-9])|([1-2][0-9])|(30)))|");
     reg.append("(0?2-?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][12");
     reg.append("35679])|([13579][01345789]))-?((((0?[13578])|(1[02]))");
     reg.append("-?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))");
     reg.append("-?((0?[1-9])|([1-2][0-9])|(30)))|(0?2-?((0?[");
     reg.append("1-9])|(1[0-9])|(2[0-8]))))))");
     Pattern p = Pattern.compile(reg.toString());
     return p.matcher(date).matches();
   }
 
   public static Date getTodayZeroDate()
   {
     Calendar calendar = Calendar.getInstance();
     int day = calendar.get(6);
     calendar.set(6, day);
     calendar.set(11, 0);
     calendar.set(12, 0);
     calendar.set(13, 0);
     calendar.set(14, 0);
     return calendar.getTime();
   }
 
   public static Date getUtcDayZero(Date in) {
     return getDayZero(in, "UTC");
   }
 
   public static Date getDayZero(Date in, String timeZone)
   {
     Calendar ca = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
     ca.setTimeInMillis(in.getTime());
     ca.set(14, 0);
     ca.set(13, 0);
     ca.set(12, 0);
     ca.set(11, 0);
     return ca.getTime();
   }
 
   public static String getDistanceTodayZeroDateAndFormate(Date date, int offset, String formate, TimeZone timeZone)
   {
     Calendar calendar = Calendar.getInstance();
     calendar.setTime(date);
     calendar.setTimeZone(timeZone);
     calendar.set(11, 0);
     calendar.set(12, 0);
     calendar.set(13, 0);
     calendar.set(14, 0);
     calendar.add(5, offset);
     return formatDate(calendar.getTime(), formate, timeZone);
   }
 
   public static String getDistanceNowCillesecondAndFormate(Date date, int offset, String formate, TimeZone timeZone)
   {
     Calendar calendar = Calendar.getInstance();
     calendar.setTime(date);
     calendar.setTimeZone(timeZone);
     calendar.set(13, 0);
     calendar.set(14, 0);
     calendar.add(11, offset);
     return formatDate(calendar.getTime(), formate, timeZone);
   }
 
   public static String formatDate(Date date, String formate, TimeZone timeZone)
   {
     SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formate);
     simpleDateFormat.setTimeZone(timeZone);
     return simpleDateFormat.format(date);
   }
 
   public static String getDate(Date date, int type, int offset, String format)
   {
     Calendar time = Calendar.getInstance();
     time.setTime(date);
     time.add(type, offset);
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     return dateFormat.format(time.getTime());
   }
 
   public static String getNowStrByTimeZone(String timezone) {
     DateTime dateTime = DateTime.now(CachedDateTimeZone.forID(timezone));
     return dateTime.toString("yyyy-MM-dd HH:mm:ss");
   }
 
   public static String getDateStrByTimeZome(Long utclong, String timezone)
   {
     DateTime dateTime = new DateTime(utclong, CachedDateTimeZone.forID(timezone));
     return dateTime.toString("yyyy-MM-dd HH:mm:ss");
   }
 
   public static Calendar FbDateToJavaDate(String fbDate)
   {
     if ((StringUtils.isNotEmpty(fbDate)) && (StringUtils.isNotBlank(fbDate))) {
       String strDate = fbDate.substring(0, 19).replace("T", " ");
       String strTimeZoneDong = fbDate.substring(19, 20);
       String strTimezone = fbDate.substring(20);
       TimeZone timeZone = TimeZone.getTimeZone("GMT" + strTimeZoneDong + strTimezone);
       Calendar calendar = Calendar.getInstance(timeZone);
       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
       sdf.setTimeZone(timeZone);
       Date date = null;
       try {
         date = sdf.parse(strDate);
       } catch (ParseException e) {
         e.printStackTrace();
       }
       calendar.setTime(date);
       return calendar;
     }
     return null;
   }
 
   public static Calendar getUtcTime(Calendar cal)
   {
     if (cal == null) {
       return null;
     }
     Calendar calendar = Calendar.getInstance(cal.getTimeZone());
     calendar.setTime(cal.getTime());
 
     int zoneOffset = calendar.get(15);
 
     int dstOffset = calendar.get(16);
 
     calendar.add(14, -(zoneOffset + dstOffset));
     return calendar;
   }
 
   public static String getNowUTC()
   {
     SimpleDateFormat foo = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:00");
 
     Calendar cal = Calendar.getInstance();
 
     int zoneOffset = cal.get(15);
 
     int dstOffset = cal.get(16);
 
     cal.add(14, -(zoneOffset + dstOffset));
 
     return foo.format(new Date(cal.getTimeInMillis()));
   }
 
   public static Date getNowUTCDate()
   {
     Calendar cal = Calendar.getInstance();
 
     int zoneOffset = cal.get(15);
 
     int dstOffset = cal.get(16);
 
     cal.add(14, -(zoneOffset + dstOffset));
 
     return new Date(cal.getTimeInMillis());
   }
 
   public static Date getUTCDate(Date date, int type, int offset) {
     Calendar time = Calendar.getInstance();
     time.setTime(date);
     time.add(type, offset);
 
     int zoneOffset = time.get(15);
 
     int dstOffset = time.get(16);
 
     time.add(14, -(zoneOffset + dstOffset));
     return new Date(time.getTimeInMillis());
   }
 
   public static Date getUtcDate(Object lastScanTime, Date nowUTCDate)
   {
     Date startTime;
     if (null == lastScanTime)
     {
       Calendar instance = Calendar.getInstance();
       instance.setTime(nowUTCDate);
       instance.set(11, 0);
       instance.set(12, 0);
       instance.set(13, 0);
       startTime = instance.getTime();
     } else {
       startTime = (Date)lastScanTime;
     }
     return startTime;
   }
 
   public static int timezoneToOffSite(String timezone) {
     return TimeZone.getTimeZone(timezone.trim()).getRawOffset() / 3600 / 1000;
   }
 }

