 package auto.common.util;
 
 import java.io.File;
 import java.io.FileInputStream;
 import java.io.FileOutputStream;
 import java.io.IOException;
 import java.util.List;
 import java.util.zip.ZipOutputStream;
 import org.apache.tools.zip.ZipEntry;
 
 public class ZipUtil
 {
   public static boolean zipSingleFile(String file, String zipFile)
     throws IOException
   {
     boolean bf = true;
     File f = new File(file);
     if (!f.exists()) {
       bf = false;
     } else {
       File ff = new File(zipFile);
       if (!f.exists()) {
         ff.createNewFile();
       }
 
       FileInputStream input = new FileInputStream(file);
 
       FileOutputStream out = new FileOutputStream(zipFile);
 
       ZipOutputStream zipOut = new ZipOutputStream(out);
 
       String fileName = f.getName();
 
       ZipEntry entry = new ZipEntry(fileName);
       zipOut.putNextEntry(entry);
 
       int number = 0;
       byte[] buffer = new byte[512];
       while ((number = input.read(buffer)) != -1) {
         zipOut.write(buffer, 0, number);
       }
       zipOut.close();
       out.close();
       input.close();
     }
     return bf;
   }
 
   public static boolean zipFiles(List<String> files, String zipfile)
     throws Exception
   {
     boolean bf = false;
 
     File ff = new File(zipfile);
 
     if (!ff.exists()) {
       ff.createNewFile();
     }
 
     FileOutputStream out = new FileOutputStream(zipfile);
 
     ZipOutputStream zipOut = new ZipOutputStream(out);
 
     for (int i = 0; i < files.size(); i++) {
       File f = new File((String)files.get(i));
       if (!f.exists()) {
         bf = false;
       }
       try
       {
         FileInputStream input = new FileInputStream((String)files.get(i));
 
         String fileName = ((String)files.get(i)).substring(((String)files.get(i)).lastIndexOf("/") + 1, ((String)files.get(i)).length());
 
         ZipEntry entry = new ZipEntry(fileName);
         zipOut.putNextEntry(entry);
 
         int nNumber = 0;
         byte[] buffer = new byte[512];
         while ((nNumber = input.read(buffer)) != -1) {
           zipOut.write(buffer, 0, nNumber);
         }
 
         input.close();
         bf = true;
       } catch (IOException e) {
         e.printStackTrace();
         bf = false;
       }
     }
     zipOut.close();
     out.close();
     return bf;
   }
 
   private static synchronized File synCopy(String filePath, String zipfile) throws IOException {
     File srcfile = new File(filePath);
     File tagTempfile = new File(zipfile + ".temp");
     FileUtil.copyFile(srcfile, tagTempfile);
     return tagTempfile;
   }
 }


