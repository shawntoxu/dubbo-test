 package auto.common.util;
 
 import auto.common.model.FileBlock;
 import java.io.File;
 import java.io.FileFilter;
 import java.io.FileInputStream;
 import java.io.FileOutputStream;
 import java.io.FileReader;
 import java.io.IOException;
 import java.io.InputStream;
 import java.io.LineNumberReader;
 import java.io.OutputStream;
 import java.security.MessageDigest;
 import java.util.ArrayList;
 import java.util.Date;
 import java.util.Iterator;
 import java.util.List;
 import java.util.regex.Matcher;
 import java.util.regex.Pattern;
 import org.apache.commons.io.FileUtils;
 import org.apache.commons.io.FilenameUtils;
 import org.apache.commons.io.IOUtils;
 import org.apache.commons.io.filefilter.DirectoryFileFilter;
 import org.apache.commons.io.filefilter.IOFileFilter;
 import org.apache.commons.io.filefilter.RegexFileFilter;
 import org.apache.commons.io.filefilter.WildcardFileFilter;
 import org.apache.commons.lang3.StringUtils;
 
 public class FileUtil
 {
   public static final String SUFFIX_TEMP = ".tmp";
   public static final String SUFFIX_TXT = ".txt";
   public static final String SUFFIX_LOG = ".log";
   public static final String SUFFIX_BAD = ".bad";
   public static final String SUFFIX_MD5 = ".md5";
   public static final String SUFFIX_SPLITVOL_VAR = ".${count}";
   public static final String SUFFIX_SEQUENCE_VAR = "${sequence:3}";
   public static final String SUFFIX_SEQUENCE_VAR_START = "${sequence:";
   private static final String mather = "\\[.+\\]";
   private static final Pattern Wilmather = Pattern.compile("\\[.+\\]");
   private static String FILE_SEPARATOR = "/";
 
   private static char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
 
   public static String getName(String filename)
   {
     return FilenameUtils.getName(filename);
   }
 
   public static String dirCompletion(String dir) {
     if (null == dir) {
       return null;
     }
     if (dir.endsWith(File.separator)) {
       return dir;
     }
     return dir + File.separator;
   }
 
   public static void moveFile(File srcFile, File destFile)
     throws IOException
   {
     FileUtils.moveFile(srcFile, destFile);
   }
 
   public static void moveAndDeleteFile(File srcFile, File destFile)
     throws IOException
   {
     if ((destFile.exists()) && 
       (!destFile.delete())) {
       throw new IOException("The file cann't be deleted.");
     }
 
     FileUtils.moveFile(srcFile, destFile);
   }
 
   public static boolean renameFileAndDeleteFile(File srcfile, File destFile)
     throws IOException
   {
     if ((destFile.exists()) && 
       (!destFile.delete())) {
       throw new IOException("The file cann't be deleted.");
     }
 
     return srcfile.renameTo(destFile);
   }
 
   public static void moveFileAndmkParent(File srcFile, File destFile)
     throws IOException
   {
     if (!destFile.getParentFile().exists())
       destFile.getParentFile().mkdirs();
     FileUtils.moveFile(srcFile, destFile);
   }
 
   public static void moveToDirectory(File srcDir, File destDir)
     throws IOException
   {
     FileUtils.moveToDirectory(srcDir, destDir, false);
   }
 
   public static void copyFile(File srcFile, File destFile)
     throws IOException
   {
     FileUtils.copyFile(srcFile, destFile);
   }
 
   public static boolean copyFileResult(File srcFile, File destFile)
   {
     try
     {
       FileUtils.copyFile(srcFile, destFile);
     } catch (IOException e) {
       e.printStackTrace();
       return false;
     }
     return true;
   }
 
   public static void copyFileAndmkParent(File srcFile, File destFile)
     throws IOException
   {
     if (!destFile.getParentFile().exists())
       destFile.getParentFile().mkdirs();
     FileUtils.copyFile(srcFile, destFile);
   }
 
   public static void copyFileToDirectory(File srcDir, File destDir)
     throws IOException
   {
     FileUtils.copyFileToDirectory(srcDir, destDir);
   }
 
   public static void copyDirectoryToDirectory(File srcDir, File destDir)
     throws IOException
   {
     FileUtils.copyDirectoryToDirectory(srcDir, destDir);
   }
 
   public static synchronized File createTempFile(String dir, String name)
     throws IOException
   {
     File tmpfile = null;
     if (checkDirAndCreate(dir)) {
       tmpfile = concatDirAndName(dir, name + "_" + DateFormatUtil.formatShort17(new Date()) + ".tmp");
       tmpfile.createNewFile();
     }
     return tmpfile;
   }
 
   public static FileInputStream getFileInputStrean(File file)
     throws IOException
   {
     return FileUtils.openInputStream(file);
   }
 
   public static FileOutputStream getFileOutputStream(File file)
     throws IOException
   {
     return FileUtils.openOutputStream(file);
   }
 
   public static String getFileContent(File file)
     throws IOException
   {
     return FileUtils.readFileToString(file, "UTF-8");
   }
 
   public static String getFileContent(File file, String encode)
     throws IOException
   {
     return FileUtils.readFileToString(file, encode);
   }
 
   public static List getFileConntent(File file, String encode)
     throws IOException
   {
     return FileUtils.readLines(file, encode);
   }
 
   public static String getInputContent(InputStream input)
     throws IOException
   {
     return IOUtils.toString(input, "UTF-8");
   }
 
   public static String getInputContent(InputStream input, String encoding)
     throws IOException
   {
     return IOUtils.toString(input, encoding);
   }
 
   public static void WriteContentToFile(File file, String str)
     throws IOException
   {
     if (!file.exists())
       file.createNewFile();
     FileUtils.writeStringToFile(file, str);
   }
 
   public static void WriteContentToFile(File file, String str, String encodeing)
     throws IOException
   {
     if (!file.exists())
       file.createNewFile();
     FileUtils.writeStringToFile(file, str, encodeing);
   }
 
   public static void WriteContentToFileUTF8(File file, String str) throws IOException {
     if (!file.exists())
       file.createNewFile();
     FileUtils.writeStringToFile(file, str, "UTF-8");
   }
 
   public static boolean isDirExsit(String dirstr)
   {
     File file = new File(dirstr);
     if (!file.exists())
       return false;
     if (!file.isDirectory())
       return false;
     return true;
   }
 
   public static boolean isFileExsit(String dirstr)
   {
     File file = new File(dirstr);
     if (!file.exists())
       return false;
     if (!file.isFile())
       return false;
     return true;
   }
 
   public static boolean checkDirAndCreate(String dirstr)
   {
     File dirfile = new File(dirstr);
     if (!dirfile.exists())
       dirfile.mkdirs();
     return isDirExsit(dirstr);
   }
 
   public static File checkDirAndCreateFile(String dirstr) {
     File dirfile = new File(dirstr);
     if (!dirfile.exists())
       dirfile.mkdirs();
     if (isDirExsit(dirstr)) return dirfile;
     return null;
   }
 
   public static File CreateUniqeNameFile(File file)
   {
     String Extension = getExtension(file.getName());
     File newfile = new File(FilenameUtils.removeExtension(file.getPath()) + "_" + DateFormatUtil.formatShort17(new Date()) + "." + Extension);
     return newfile;
   }
 
   public static String CreateUniqeName(String filename)
   {
     String Extension = getExtension(filename);
     String newname = getFileBaseName(filename) + "_" + DateFormatUtil.formatShort17(new Date()) + "." + Extension;
     return newname;
   }
 
   public static String InsertStrToBaseName(String filename, String str)
   {
     String Extension = getExtension(filename);
     String newname = getFileBaseName(filename) + "_" + str + "." + Extension;
     return newname;
   }
 
   public static String InsertStrToBaseNames(String filename, String str)
   {
     String Extension = getExtension(filename);
     String newname = getFileBaseName(filename) + "" + str + "." + Extension;
     return newname;
   }
 
   public static File ReplaceExtension(File file, String newextension)
   {
     File newfile = new File(FilenameUtils.removeExtension(file.getPath()) + newextension);
     return newfile;
   }
 
   public static boolean CreateDir(String dirstr)
   {
     File dirfile = new File(dirstr);
     dirfile.mkdirs();
     return isDirExsit(dirstr);
   }
 
   public static boolean isFileExistAndCanRW(String filepath)
   {
     File file = new File(filepath);
     if (!file.exists())
       return false;
     if (!file.isFile())
       return false;
     if (!file.canRead())
       return false;
     if (!file.canWrite())
       return false;
     return true;
   }
 
   public static boolean isFileExistAndRead(String filepath)
   {
     File file = new File(filepath);
     if (!file.exists())
       return false;
     if (!file.isFile())
       return false;
     if (!file.canRead())
       return false;
     return true;
   }
 
   public static void deleteDirectory(File directory)
     throws IOException
   {
     FileUtils.deleteDirectory(directory);
   }
 
   public static boolean deleteQuietly(File file)
   {
     return FileUtils.deleteQuietly(file);
   }
 
   public static String getFileBaseName(String filename)
   {
     return FilenameUtils.getBaseName(filename);
   }
 
   public static boolean isExtension(String filename, String extension, boolean iscase)
   {
     if (iscase) {
       return FilenameUtils.isExtension(filename, extension);
     }
     return (FilenameUtils.isExtension(filename, extension.toLowerCase())) || (FilenameUtils.isExtension(filename, extension.toUpperCase()));
   }
 
   public static String getExtension(String filename)
   {
     return FilenameUtils.getExtension(filename);
   }
 
   public static File concatDirAndName(String dir, String filename)
   {
     return new File(FilenameUtils.concat(dir, filename));
   }
 
   public static String concatPath(String dir, String subdir)
   {
     return FilenameUtils.concat(dir, subdir);
   }
 
   public static File ReplaceBasePath(String basepath, String newpath, File file)
   {
     if ((StringUtil.isEmpty(newpath)) || (file == null))
       return file;
     if (StringUtil.isNotEmpty(basepath))
       basepath = file.getParent();
     String filepath = normalizePath(file.getPath());
     basepath = normalizePath(basepath);
     newpath = normalizePath(newpath);
     String RelativePath = StringUtils.removeStart(filepath, basepath);
     if (RelativePath.startsWith(FILE_SEPARATOR))
       RelativePath = RelativePath.substring(1);
     return concatDirAndName(newpath, RelativePath);
   }
 
   public static List<File> FileListForWildcardFileFilter(File dir, String wildcardStr, boolean includesubdir)
   {
     List filelist = new ArrayList();
     if (!dir.isDirectory())
       return filelist;
     IOFileFilter fileFilter = null;
     IOFileFilter dirFilter = null;
     try {
       fileFilter = new WildcardFileFilter(getParseWildcard(wildcardStr));
       if (includesubdir)
         dirFilter = new WildcardFileFilter("*");
       else
         dirFilter = new WildcardFileFilter(".");
     } catch (Exception e) {
       e.printStackTrace();
     }
     Iterator iterator = FileUtils.iterateFiles(dir, fileFilter, dirFilter);
     for (Iterator iterator2 = iterator; iterator2.hasNext(); ) {
       File tmpfiles = (File)iterator2.next();
       filelist.add(tmpfiles);
     }
     return filelist;
   }
 
   public static boolean wildcardMatchForFileName(String filename, String wildcardMatcher)
   {
     if (StringUtil.isNotEmpty(wildcardMatcher))
       return false;
     String[] wildcards = getParseWildcard(wildcardMatcher);
     for (String string : wildcards) {
       if (FilenameUtils.wildcardMatch(filename, string))
         return true;
     }
     return false;
   }
 
   public static boolean RegexMatchForFileName(String filename, String regstr)
   {
     Pattern pattern = null;
     if (StringUtil.isNotEmpty(regstr))
       pattern = Pattern.compile(regstr);
     else
       pattern = null;
     if (pattern != null)
       return pattern.matcher(filename).matches();
     return false;
   }
 
   public static List<File> FileListForRegexFileFilter(File dir, String RegStr, boolean includesubdir)
   {
     List filelist = new ArrayList();
     if (!dir.isDirectory())
       return filelist;
     IOFileFilter fileFilter = null;
     IOFileFilter dirFilter = null;
     try {
       fileFilter = new RegexFileFilter(RegStr);
       if (includesubdir)
         dirFilter = new WildcardFileFilter("*");
       else
         dirFilter = new WildcardFileFilter(".");
     } catch (Exception e) {
       e.printStackTrace();
     }
     Iterator iterator = FileUtils.iterateFiles(dir, fileFilter, dirFilter);
     for (Iterator iterator2 = iterator; iterator2.hasNext(); ) {
       File tmpfiles = (File)iterator2.next();
       filelist.add(tmpfiles);
     }
     return filelist;
   }
 
   public static File[] FileArrayForWildcardFileFilter(File dir, String wildcardStr)
   {
     FileFilter fileFilter = new WildcardFileFilter(getParseWildcard(wildcardStr));
     File[] files = dir.listFiles(fileFilter);
     return files;
   }
 
   public static File[] FileArrayForRegexFileFilter(File dir, String wildcardStr)
   {
     FileFilter fileFilter = new RegexFileFilter(wildcardStr);
     File[] files = dir.listFiles(fileFilter);
     return files;
   }
 
   public static String[] FileArrayForDirectoryFileFilter(File dir, String wildcardStr)
   {
     String[] files = dir.list(DirectoryFileFilter.INSTANCE);
     return files;
   }
 
   public static WildcardFileFilter getWildcardFileFilter(String wildcardStr)
   {
     WildcardFileFilter fileFilter = new WildcardFileFilter(getParseWildcard(wildcardStr));
     return fileFilter;
   }
 
   public static String getFileMd5(File file)
   {
     try
     {
       MessageDigest messagedigest = MessageDigest.getInstance("MD5");
       InputStream fis = new FileInputStream(file);
       byte[] buffer = new byte[1024];
       int numRead = 0;
       while ((numRead = fis.read(buffer)) > 0) {
         messagedigest.update(buffer, 0, numRead);
       }
       fis.close();
       return bufferToHex(messagedigest.digest());
     } catch (Exception e) {
       e.printStackTrace();
     }
     return null;
   }
 
   public static String getFileMd5(byte[] file)
   {
     try
     {
       MessageDigest messagedigest = MessageDigest.getInstance("MD5");
       messagedigest.update(file);
       return bufferToHex(messagedigest.digest());
     } catch (Exception e) {
       e.printStackTrace();
     }
     return null;
   }
 
   private static String bufferToHex(byte[] bytes)
   {
     return bufferToHex(bytes, 0, bytes.length);
   }
 
   private static String bufferToHex(byte[] bytes, int m, int n)
   {
     StringBuffer stringbuffer = new StringBuffer(2 * n);
     int k = m + n;
     for (int l = m; l < k; l++) {
       appendHexPair(bytes[l], stringbuffer);
     }
     return stringbuffer.toString();
   }
 
   private static void appendHexPair(byte bt, StringBuffer stringbuffer)
   {
     char c0 = hexDigits[((bt & 0xF0) >> 4)];
     char c1 = hexDigits[(bt & 0xF)];
     stringbuffer.append(c0);
     stringbuffer.append(c1);
   }
 
   public static RegexFileFilter getRegexFileFilter(String RegStr)
   {
     RegexFileFilter fileFilter = new RegexFileFilter(RegStr);
     return fileFilter;
   }
 
   private static String[] getParseWildcard(String str)
   {
     List morelist = new ArrayList();
     parseString(str, morelist);
     String[] strs = new String[morelist.size()];
     for (int i = 0; i < strs.length; i++) {
       strs[i] = ((String)morelist.get(i));
     }
     return strs;
   }
 
   private static void parseString(String str, List<String> morelist)
   {
     String[] srcs = null;
     Matcher matcher = Wilmather.matcher(str);
     if (!matcher.find()) {
       morelist.add(str);
     } else {
       StringBuffer buffer = new StringBuffer(str);
       int start = buffer.indexOf("[");
       int end = buffer.indexOf("]");
       String mat = buffer.substring(start, end + 1);
       char[] morestr = buffer.substring(start + 1, end).toCharArray();
       srcs = new String[morestr.length];
       for (int i = 0; i < srcs.length; i++)
         parseString(str.replace(mat, String.valueOf(morestr[i])), morelist);
     }
   }
 
   public static String normalizePath(String path)
   {
     String normalizedPath = path.replaceAll("\\\\", FILE_SEPARATOR);
     while ((normalizedPath.endsWith("\\")) || (normalizedPath.endsWith(FILE_SEPARATOR))) {
       normalizedPath = normalizedPath.substring(0, normalizedPath.length() - 1);
     }
 
     return normalizedPath;
   }
 
   public static String ftpPath(String path)
   {
     String ftppath = StringUtils.replaceChars(path, '\\', '/');
     return ftppath;
   }
 
   public static long getLineNumByRead(File file)
     throws IOException
   {
     LineNumberReader reader = null;
     try {
       reader = new LineNumberReader(new FileReader(file));
       reader.skip(file.length());
       return reader.getLineNumber();
     } finally {
       if (reader != null)
         reader.close();
     }
   }
 
   public static String getProjectName(String path)
   {
     String unixpath = FilenameUtils.separatorsToUnix(path);
     int startindex = unixpath.indexOf(FILE_SEPARATOR);
     if (startindex == 0) {
       unixpath = unixpath.substring(1);
       startindex = unixpath.indexOf(FILE_SEPARATOR);
     }
     if (startindex > -1)
       return unixpath.substring(0, startindex);
     return unixpath;
   }
 
   public static String getFileName(String filepath)
   {
     return FilenameUtils.getName(filepath);
   }
 
   public static void removeAllFile(String keyWord, String path)
   {
     File f = new File(path);
     if ((!f.exists()) || (!f.isDirectory())) {
       return;
     }
     File[] fLst = f.listFiles();
     for (File tf : fLst)
       if (tf.getName().startsWith(String.valueOf(keyWord)))
         tf.delete();
   }
 
   public static void exportFile(OutputStream outputStream, InputStream inputStream)
     throws IOException
   {
     try
     {
       int DEFAULT_BUFFER_SIZE = 4096;
       int charactor = 0;
       byte[] buff = new byte[DEFAULT_BUFFER_SIZE];
       while (-1 != (charactor = inputStream.read(buff))) {
         outputStream.write(buff, 0, charactor);
       }
       outputStream.flush();
 
       if (null != outputStream) {
         outputStream.close();
       }
       if (null != inputStream)
         inputStream.close();
     }
     finally
     {
       if (null != outputStream) {
         outputStream.close();
       }
       if (null != inputStream)
         inputStream.close();
     }
   }
 
   public static List<FileBlock> SplitBySize(File srcfile, int blocksize)
     throws IOException
   {
     List blockList = new ArrayList();
     if (srcfile.length() <= blocksize) {
       FileBlock block = new FileBlock();
       block.setMd5(getFileMd5(srcfile));
       block.setEndPosition((int)srcfile.length());
       block.setSeq_no(0);
       block.setStartPosition(0);
       block.setBlockfile(srcfile);
       block.setSize((int)srcfile.length());
       blockList.add(block);
       return blockList;
     }
     InputStream ips = null;
     OutputStream ops = null;
     byte[] buffer = null;
     int partNumber = 0;
     ips = new FileInputStream(srcfile);
     buffer = new byte[blocksize];
     int tempLength = 0;
     int start = 0;
     int end = 0;
     while ((tempLength = ips.read(buffer, 0, blocksize)) != -1) {
       String targetFilePath = srcfile.getAbsolutePath() + ".block_" + partNumber;
       File blockfile = new File(targetFilePath);
       FileBlock fileBlock = new FileBlock();
       fileBlock.setBlockfile(blockfile);
       fileBlock.setSeq_no(partNumber);
       fileBlock.setSize(tempLength);
       fileBlock.setStartPosition(start);
       ops = new FileOutputStream(blockfile);
       ops.write(buffer, 0, tempLength);
       ops.close();
       end = start + tempLength;
       fileBlock.setEndPosition(end);
       fileBlock.setMd5(getFileMd5(blockfile));
       start = end;
       blockList.add(fileBlock);
       partNumber++;
     }
 
     ips.close();
     return blockList;
   }
 
   public static void combineFile(File tarfile, List<FileBlock> blocks) throws Exception
   {
     OutputStream eachFileOutput = new FileOutputStream(tarfile);
     for (FileBlock block : blocks) {
       InputStream eachFileInput = new FileInputStream(block.getBlockfile());
       byte[] buffer = new byte[1048576];
       int len = 0;
       while ((len = eachFileInput.read(buffer, 0, 1048576)) != -1)
       {
         eachFileOutput.write(buffer, 0, len);
       }
       eachFileInput.close();
     }
     eachFileOutput.close();
   }
 }

