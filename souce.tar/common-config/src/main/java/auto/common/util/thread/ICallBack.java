package auto.common.util.thread;

public abstract interface ICallBack
{
  public abstract <T> void execute(T paramT);
}

