 package auto.common.util;
 
 import auto.common.model.DateModel;
 import java.text.ParseException;
 import java.text.SimpleDateFormat;
 import java.util.Calendar;
 import java.util.Date;
 import java.util.TimeZone;
 import java.util.regex.Matcher;
 import java.util.regex.Pattern;
 import org.joda.time.DateTime;
 
 public class DateFormatUtil
 {
   public static final Pattern validDatePatten = Pattern.compile("^((\\d{2}(([02468][048])|([13579][26]))-((((0?[13578])|(1[02]))-((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))-((0?[1-9])|([1-2][0-9])|(30)))|(0?2-((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))-((((0?[13578])|(1[02]))-((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))-((0?[1-9])|([1-2][0-9])|(30)))|(0?2-((0?[1-9])|(1[0-9])|(2[0-8]))))))");
   public static final String FORMAT_STR_19 = "yyyy-MM-dd HH:mm:ss";
   public static final String FORMAT_STR_10 = "yyyy-MM-dd";
   public static final String FORMAT_STR_19_ZERO = "yyyy-MM-dd 00:00:00";
   public static final String TIME_ZONE_GMT = "GMT";
   public static final String TIME_ZONE_GMT0 = "GMT+0";
   public static final String TIME_ZONE_UTC = "UTC";
 
   public static String formatLong10(Date date)
   {
     return format(date, "yyyy-MM-dd");
   }
 
   public static String formatLong10_(Date date)
   {
     return format(date, "yyyy/MM/dd");
   }
 
   public static String formatLong19(Date date)
   {
     return format(date, "yyyy-MM-dd HH:mm:ss");
   }
 
   public static String formatLong13(Date date) {
     return format(date, "yyyy-MM-dd HH");
   }
 
   public static String format(Date date, SimpleDateFormat format)
   {
     if (date == null) {
       return "";
     }
     return format.format(date);
   }
 
   public static String format(Date date, String formatPattern)
   {
     String formatstr = null;
     if (date != null) {
       try {
         DateTime dateTime = new DateTime(date);
         formatstr = dateTime.toString(formatPattern);
       } catch (Exception e) {
         e.printStackTrace();
       }
     }
     return formatstr;
   }
 
   public static String format(Long longtime, String formatPattern)
   {
     Date date = new Date(longtime.longValue());
     return format(date, formatPattern);
   }
 
   public static String format(Date date, String format, String TimeZoneID)
   {
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     dateFormat.setTimeZone(TimeZone.getTimeZone(TimeZoneID));
     return dateFormat.format(date);
   }
 
   public static String formatShort8(Date date)
   {
     return format(date, "yyyyMMdd");
   }
 
   public static String formatShort6(Date date)
   {
     return format(date, "yyyyMM");
   }
 
   public static String formatShort4(Date date) {
     return format(date, "yyyy");
   }
 
   public static String formatShort10(Date date)
   {
     return format(date, "yyyyMMddHH");
   }
 
   public static String formatShort12(Date date)
   {
     return format(date, "yyyyMMddHHmm");
   }
 
   public static String formatShort17(Date date)
   {
     return format(date, "yyyyMMddHHmmssSSS");
   }
 
   public static Date parseDateShort8(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatShort8 = new SimpleDateFormat("yyyyMMdd");
       return sFormatShort8.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateShort6(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatShort6 = new SimpleDateFormat("yyyyMM");
       return sFormatShort6.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateShort4(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatShort4 = new SimpleDateFormat("yyyy");
       return sFormatShort4.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateShort10(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatShort10 = new SimpleDateFormat("yyyyMMddHH");
       return sFormatShort10.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateLong7(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatLong7 = new SimpleDateFormat("yyyy-MM");
       return sFormatLong7.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateLong10(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatLong10 = new SimpleDateFormat("yyyy-MM-dd");
       return sFormatLong10.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateLong10_(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatLong10 = new SimpleDateFormat("yyyy/MM/dd");
       return sFormatLong10.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateLong10_2(String strDate)
   {
     try {
       SimpleDateFormat sFormatLong10_2 = new SimpleDateFormat("dd/MM/yyyy");
       return sFormatLong10_2.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateLong13(String strDate)
   {
     try {
       SimpleDateFormat sFormatLong13 = new SimpleDateFormat("yyyy-MM-dd HH");
       return sFormatLong13.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDateShort14(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatShort14 = new SimpleDateFormat("yyyyMMddHHmmss");
       return sFormatShort14.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static String formatDateShort14(Date date)
   {
     return format(date, "yyyyMMddHHmmss");
   }
 
   public static Date parseDateLong19(String strDate)
   {
     try
     {
       SimpleDateFormat sFormatLong19 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
       return sFormatLong19.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static Date parseDate(String strDate, SimpleDateFormat format)
   {
     try
     {
       return format.parse(strDate); } catch (ParseException e) {
     }
     throw new IllegalArgumentException("Unable to parse the strDate: " + strDate);
   }
 
   public static String formatWithTimezone(String dateStr, String format, String fromTimeZone, String toTimeZone)
   {
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     if (null != fromTimeZone)
       dateFormat.setTimeZone(TimeZone.getTimeZone(fromTimeZone));
     try
     {
       Date e = dateFormat.parse(dateStr);
       dateFormat.setTimeZone(TimeZone.getTimeZone(toTimeZone));
       return dateFormat.format(Long.valueOf(e.getTime()));
     } catch (ParseException e) {
       e.printStackTrace();
     }
     return null;
   }
 
   public static boolean isValidDate(String strDate)
   {
     Matcher m = validDatePatten.matcher(strDate);
     return m.matches();
   }
 
   public static String formatLong20(Date date)
   {
     return format(date, "yyyy年MM月dd日");
   }
 
   public static String formatLongMsg(Date date)
   {
     return format(date, "yyyy年MM月dd日 HH:mm");
   }
 
   public static String formatM12(Date date)
   {
     return format(date, "MM月dd日 HH:mm");
   }
 
   public static String formatLong16_(Date date)
   {
     return format(date, "yyyy-MM-dd HH:mm");
   }
 
   public static String formatLong16(Date date)
   {
     return format(date, "yyyy/MM/dd HH:mm");
   }
 
   public static DateModel getDateModel(Date date, String format, String timeZone)
   {
     Calendar time = Calendar.getInstance();
     time.setTime(date);
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     if (null != timeZone) {
       dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
     }
     DateModel dm = new DateModel();
     dm.setFromTimeZone(timeZone);
     dm.setDate(date);
     dm.setTimeString(dateFormat.format(time.getTime()));
     dm.setUtcTime(Long.valueOf(time.getTimeInMillis()));
     dm.setFormat(format);
     dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
     dm.setToTimeString(dateFormat.format(Long.valueOf(date.getTime())));
     return dm;
   }
 
   public static DateModel getDateModel(String dateStr, String format, String timeZone)
   {
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     if (null != timeZone) {
       dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
     }
 
     DateModel dm = new DateModel();
     try {
       Date date = dateFormat.parse(dateStr);
       dm.setDate(date);
       dm.setUtcTime(Long.valueOf(date.getTime()));
       dm.setTimeString(dateStr);
       dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
       dm.setToTimeString(dateFormat.format(Long.valueOf(date.getTime())));
     } catch (ParseException e) {
       e.printStackTrace();
     }
     dm.setFromTimeZone(timeZone);
     dm.setFormat(format);
     return dm;
   }
 
   public static DateModel getDate(String dateStr, String format, String fromTimeZone, String toTimeZone)
   {
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     if (null != fromTimeZone) {
       dateFormat.setTimeZone(TimeZone.getTimeZone(fromTimeZone));
     }
 
     DateModel dm = new DateModel();
     try {
       Date date = dateFormat.parse(dateStr);
       dm.setDate(date);
       dm.setUtcTime(Long.valueOf(date.getTime()));
       dm.setTimeString(dateStr);
       dateFormat.setTimeZone(TimeZone.getTimeZone(toTimeZone));
       dm.setToTimeString(dateFormat.format(Long.valueOf(date.getTime())));
     } catch (ParseException e) {
       e.printStackTrace();
     }
     dm.setFromTimeZone(fromTimeZone);
     dm.setFormat(format);
     return dm;
   }
 
   public static DateModel getDate(Date date, String format, String fromTimeZone, String toTimeZone)
   {
     Calendar time = Calendar.getInstance();
     time.setTime(date);
     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
     if (null != fromTimeZone) {
       dateFormat.setTimeZone(TimeZone.getTimeZone(fromTimeZone));
     }
     DateModel dm = new DateModel();
     dm.setFromTimeZone(fromTimeZone);
     dm.setDate(date);
     dm.setTimeString(dateFormat.format(time.getTime()));
     dm.setUtcTime(Long.valueOf(time.getTimeInMillis()));
     dm.setFormat(format);
     dateFormat.setTimeZone(TimeZone.getTimeZone(toTimeZone));
     dm.setToTimeString(dateFormat.format(Long.valueOf(date.getTime())));
     return dm;
   }
 }
