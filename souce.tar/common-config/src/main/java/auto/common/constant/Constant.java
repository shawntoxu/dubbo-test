 package auto.common.constant;
 
 import auto.common.util.StringUtil;
 import java.io.PrintStream;
 
 public class Constant
 {
   public static final String UTF8 = "UTF-8";
   public static final String RESTART_FILE_LOCK = "config_restart.lock";
   public static final String STOP_APP_FLAG = "STOP";
   public static final String STARTED_APP_FLAG = "STARTED";
   public static final String ZK_CONFIG_ROOTNODE = "/auto/common/config";
   public static final String ZK_CONF_ENCODING = "UTF-8";
   public static final int ZK_TIMEOUT = 30000;
   public static final String ZK_ADDRESS = getZkAddress();
 
   private static String getZkAddress()
   {
     String address = System.getenv("ZK_ADDRESS");
     if (StringUtil.isEmpty(address)) {
       System.err.println("System EVN Variable Not Config 'ZK_ADDRESS',Please Config It,System exit");
       System.exit(0);
     }
     return address;
   }
 }
