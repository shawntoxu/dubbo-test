 package auto.common.container;
 
 public class SpringBootWebContainer extends SpringBootContainer
 {
   public SpringBootWebContainer()
   {
     this.isweb = true;
   }
 }

