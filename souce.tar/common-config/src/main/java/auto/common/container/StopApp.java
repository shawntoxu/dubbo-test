 package auto.common.container;
 
 import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
 import auto.common.config.ConfigCentre;
 import auto.common.util.FileUtil;
 import auto.common.util.StringUtil;
 import auto.common.util.ThreadPool;
 import java.io.File;
 import java.lang.reflect.InvocationTargetException;
 import java.lang.reflect.Method;
 import java.util.concurrent.Callable;
 import java.util.concurrent.TimeUnit;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.context.ConfigurableApplicationContext;
 
 public class StopApp
 {
   static Logger logger = LoggerFactory.getLogger(StopApp.class);
 
   private static int scan_lock_file_interval = 2000;
 
   static void RegisterStopApp(final File lockFile, final ConfigurableApplicationContext context, final Callable callable)
   {
     new Thread()
     {
       public void run() {
         long lastModified = lockFile.lastModified();
         if (callable != null) {
           StopApp.logger.info(">>>> 注册ShutdownHook");
           Runtime.getRuntime().addShutdownHook(new Thread()
           {
             public void run() {
               try {
                 StopApp.logger.info(">>>> ShutdownHook被调用");
                  callable.call();
               } catch (Exception e) {
                 e.printStackTrace(System.err);
                 StopApp.logger.error("error >> 注册ShutdownHook", e);
               }
             }
           });
         }
         try
         {
           while (true)
           {
             Thread.sleep(StopApp.scan_lock_file_interval);
             long tmpLastModified = lockFile.lastModified();
             StopApp.logger.trace("old>>>" + lastModified + " ;new>>>" + tmpLastModified);
             if (lastModified == tmpLastModified) {
               StopApp.logger.trace("   xxxxxxxxx continue   ");
             }
             else {
               lastModified = tmpLastModified;
               String content = FileUtil.getFileContent(lockFile);
               StopApp.logger.debug("content>>>>>" + content);
               StopApp.logger.debug("length>>>" + content.length());
               if ((StringUtil.isNotEmpty(content)) && (content.startsWith("STOP"))) {
                 StopApp.logger.info(">>>> lockFile 文件内容修改关闭服务应用开始");
 
                 StopApp.closeApp(context);
                 System.exit(0);
                 break;
               }
             }
           } } catch (Exception e) { e.printStackTrace(System.err);
           StopApp.logger.error("error >> 服务异常", e);
         }
       }
 
     }
 
     .start();
   }
 
   private static void closeApp(ConfigurableApplicationContext context)
   {
     int wait_stop_app_time = ConfigCentre.getInteger("wait.stop.app.time", Integer.valueOf(60)).intValue();
 
     logger.info("xxxxxxxxxxx >> 关闭dubbo服务开始");
 
     AbstractRegistryFactory.destroyAll();
     logger.info("xxxxxxxxxxx >> 关闭dubbo服务完成");
     try
     {
       Class clazz = Class.forName("auto.common.mq.consumer.AllConsumerHolder");
       Method destroyAll = clazz.getMethod("destroyAll", null);
       destroyAll.invoke(null, null);
       logger.error("xxxxxxxxxxx尝试关闭mq消费者完成");
     } catch (ClassNotFoundException localClassNotFoundException) {
     }
     catch (NoSuchMethodException|InvocationTargetException|IllegalAccessException e) {
       logger.error("xxxxxxxxxxx尝试关闭mq消费者异常", e);
     }
     try
     {
       logger.info("等待" + wait_stop_app_time + "秒钟，关闭spring");
       TimeUnit.SECONDS.sleep(wait_stop_app_time);
     } catch (InterruptedException e) {
       e.printStackTrace();
     }
 
     logger.info("xxxxxxxxxxx >> 关闭Spring服务开始");
     if (context != null)
       context.close();
     else {
       logger.info("spring被异常停止");
     }
     logger.info("xxxxxxxxxxx >> 关闭Spring服务完成");
     logger.info("xxxxxxxxxxx >> 关闭线程池服务开始");
     try {
       ThreadPool.shutdown();
       for (int j = 0; j < 2; j++) {
         boolean flag = ThreadPool.awaitTermination(wait_stop_app_time, TimeUnit.SECONDS);
         logger.info("xxxxxxxxxxx尝试关闭ThreadPool j>> " + j + " ,flag >>>" + flag);
         if (flag)
           break;
       }
     }
     catch (Exception e) {
       logger.error("关闭线程池异常>>>", e);
     }
     logger.info("xxxxxxxxxxx >> 关闭线程池服务完成");
   }
 }

