package auto.common.container;

import java.util.Map;
import org.springframework.context.ApplicationContext;

public abstract interface ConfigWatcher
{
  public abstract void notification(ApplicationContext paramApplicationContext, String paramString, Map<String, String> paramMap);
}

