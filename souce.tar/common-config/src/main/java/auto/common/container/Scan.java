 package auto.common.container;
 
 import auto.common.config.BaseConfig;
 import java.io.File;
 import java.io.FileFilter;
 import java.io.IOException;
 import java.io.PrintStream;
 import java.net.JarURLConnection;
 import java.net.URL;
 import java.net.URLDecoder;
 import java.util.ArrayList;
 import java.util.Enumeration;
 import java.util.LinkedHashSet;
 import java.util.List;
 import java.util.Set;
 import java.util.jar.JarEntry;
 import java.util.jar.JarFile;
 
 public class Scan
 {
   public static final String CLASSSOURCE = "classsource";
   public static final String XMLRESOURCE = "xmlresource";
   
   public static final String PACKAGE_PRE="auto\\common" ;
   public static final String PACKAGE_PRE2="auto/common" ;
   public static final String PACKAGE_PRE3="auto.common" ;

 
   public static Class[] getApplicationClass()
   {
     List clist = new ArrayList();
     Set<Class<?>> clsset = getClasses(PACKAGE_PRE3);
     for (Class it : clsset) {
       if (it.getSuperclass() != null) {
         if (it.getSuperclass().equals(BaseConfig.class))
           clist.add(it);
         else if (it.getName().contains("CommonBeanApplication")) {
           clist.add(it);
         }
       }
 
     }
 
     if (clist.size() == 0) {
       clist.add(BaseConfig.class);
       System.out.println("warning !!! Scan Not Fount Applection Class ,Use BaseConfig");
     }
     return (Class[])clist.toArray(new Class[clist.size()]);
   }
 
   public static Set<Class<?>> getClasses(String pack)
   {
     Set classes = new LinkedHashSet();
     boolean recursive = true;
     String packageName = pack;
     String packageDirName = packageName.replace('.', '/');
     try
     {
       Enumeration dirs = Thread.currentThread().getContextClassLoader().getResources(packageDirName);
       while (dirs.hasMoreElements()) {
         URL url = (URL)dirs.nextElement();
         String protocol = url.getProtocol();
         if ("file".equals(protocol)) {
           String filePath = URLDecoder.decode(url.getFile(), "UTF-8");
           findAndAddClassesInPackageByFile(filePath, recursive, classes);
         } else if ("jar".equals(protocol))
         {
           try {
             JarFile jar = ((JarURLConnection)url.openConnection()).getJarFile();
             Enumeration entries = jar.entries();
             while (entries.hasMoreElements()) {
               JarEntry entry = (JarEntry)entries.nextElement();
               String name = entry.getName();
               if (name.charAt(0) == '/') {
                 name = name.substring(1);
               }
               if (name.startsWith(packageDirName)) {
                 int idx = name.lastIndexOf('/');
                 if (idx != -1) {
                   packageName = name.substring(0, idx).replace('/', '.');
                 }
                 if (((idx != -1) || (recursive)) && 
                   (name.endsWith(".class")) && (!entry.isDirectory())) {
                   String className = name.substring(packageName.length() + 1, name.length() - 6);
                   try {
                     classes.add(Class.forName(packageName + '.' + className));
                   } catch (ClassNotFoundException e) {
                     System.out.println("warning !!! Sanc Jar,Class Not Found " + packageName + '.' + className);
                   }
                 }
               }
             }
           }
           catch (IOException e) {
             e.printStackTrace();
           }
         }
       }
     } catch (IOException e) {
       e.printStackTrace();
     }
 
     return classes;
   }
 
   private static void findAndAddClassesInPackageByFile(String packagePath, final boolean recursive, Set<Class<?>> classes)
   {
     File dir = new File(packagePath);
     if ((!dir.exists()) || (!dir.isDirectory())) {
       return;
     }
     File[] dirfiles = dir.listFiles(new FileFilter() {
       public boolean accept(File file) {
         return ( recursive && (file.isDirectory())) || (file.getName().endsWith(".class"));
       }
     });
     for (File file : dirfiles)
       if (file.isDirectory()) {
         findAndAddClassesInPackageByFile(file.getAbsolutePath(), recursive, classes);
       }
       else
         try
         {
           if ((file.getPath().contains(PACKAGE_PRE)) || (file.getPath().contains(PACKAGE_PRE2)))
             classes.add(Thread.currentThread().getContextClassLoader().loadClass(getClassNameByPath(file.getPath())));
         }
         catch (ClassNotFoundException e)
         {
           System.out.println("warning !!! Sanc class dir Class Not Found " + file.getPath());
         }
   }
 
   static String getClassNameByPath(String path)
   {
     int classessIndex = path.indexOf("classes");
     String classpath = path.substring(classessIndex + 8, path.length() - 6).replace("\\", ".");
     return classpath.replace("/", ".");
   }
 }
