package auto.common.container;

public abstract interface ContainerInitBefore
{
  public abstract void doBefore();
}

