 package auto.common.container;
 
 import com.alibaba.dubbo.container.Container;
 import com.alibaba.dubbo.registry.Registry;
 import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
 import auto.common.config.BaseConfig;
 import auto.common.config.ConfigCentre;
 import auto.common.util.EnvUtil;
 import auto.common.util.FileUtil;
 import java.io.File;
 import java.io.IOException;
 import java.io.PrintStream;
 import java.util.ArrayList;
 import java.util.Collection;
 import java.util.List;
 import java.util.concurrent.Callable;
 import java.util.concurrent.TimeUnit;
 import org.apache.commons.io.FileUtils;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.boot.SpringApplication;
 import org.springframework.boot.builder.SpringApplicationBuilder;
 import org.springframework.context.ConfigurableApplicationContext;
 
 public class SpringBootContainer
   implements Container
 {
   static Logger logger = LoggerFactory.getLogger(SpringBootContainer.class);
   public static SpringApplicationBuilder springApplicationBuilder;
   public static ConfigurableApplicationContext context;
   public static List<ContainerPost> containerPostList = new ArrayList();
 
   public static List<ContainerInitBefore> containerInitBefores = new ArrayList();
 
   boolean isweb = false;
 
   public ConfigurableApplicationContext getContext()
   {
     return context;
   }
 
   public void start()
   {
     System.out.print("start spring boot container ");
     logger.info("start spring boot container ");
 
     Class[] classarray = Scan.getApplicationClass();
     ConfigCentre.RegisterAppIds(classarray);
     runInitBefore();
     checkStarted();
     springApplicationBuilder = new SpringApplicationBuilder(new Object[0]).sources(classarray);
     springApplicationBuilder.application().setWebEnvironment(this.isweb);
     springApplicationBuilder.run(new String[0]);
     System.out.println("---------springApplicationBuilder  Container OK----------- ");
     logger.info("---------springApplicationBuilder OK----------- ");
     context = springApplicationBuilder.context();
     context.start();
     System.out.println("---------Start Spring Boot Container OK----------- ");
     logger.info("---------Start Spring Boot Container OK----------- ");
     ConfigCentre.springBootContainer = this;
     runPost();
   }
 
   private void checkStarted()
   {
     Thread thread = new Thread()
     {
       public void run() {
         System.out.println("----BaseConfig.DEV >>>>>" + BaseConfig.DEV);
         SpringBootContainer.logger.info("----BaseConfig.DEV >>>>>" + BaseConfig.DEV);
 
         if (!BaseConfig.DEV)
         {
           final File lockFile = new File(EnvUtil.getWorkDir() + "/bin/" + "config_restart.lock");
           SpringBootContainer.logger.info("----准备锁文件 >>>>>" + lockFile.getAbsolutePath());
           if (lockFile.exists()) {
             SpringBootContainer.logger.info("----锁文件已经存在 删除 >>>>>");
             lockFile.delete();
             SpringBootContainer.logger.info("----锁文件已经存在 删除完成 >>>>>");
           }
           try {
             SpringBootContainer.logger.info("----锁文件不存在 准备创建 >>>>>");
             lockFile.createNewFile();
             SpringBootContainer.logger.info("----锁文件不存在 创建完成 >>>>>");
           } catch (IOException e) {
             e.printStackTrace(System.err);
             SpringBootContainer.logger.error("----锁文件不存在 出错 >>>>>", e);
           }
 
           SpringBootContainer.logger.info("--- 判断Registry是否全部注册成功 >>>>>");
           while (true) {
             boolean isComplete = true;
             Collection<Registry> regsitries2 = AbstractRegistryFactory.getRegistries();
             SpringBootContainer.logger.info("regsitries sum >>>> " + regsitries2.size());
             for (Registry regsitry : regsitries2) {
               if (!regsitry.isAvailable()) {
                 isComplete = false;
               }
             }
             if ((isComplete) && (regsitries2.size() > 0))
               break;
             try
             {
               Thread.sleep(2000L);
             } catch (InterruptedException e) {
               e.printStackTrace();
             }
             SpringBootContainer.logger.info("没有完全注册完成>>需要等待2秒，在判断isComplete >> " + isComplete + " ; regsitries.size() >> " + regsitries2.size());
           }
           SpringBootContainer.logger.info("--- Registry全部注册成功 >>>>>");
 
           int wait_start_app_time = ConfigCentre.getInteger("wait.start.app.time", Integer.valueOf(60)).intValue();
           try {
             SpringBootContainer.logger.info("等待别的系接受zk请求>>>" + wait_start_app_time);
             TimeUnit.SECONDS.sleep(wait_start_app_time);
           } catch (InterruptedException e) {
             e.printStackTrace();
           }
 
           SpringBootContainer.logger.info("----准备写入成功标记 >>>>>" + lockFile.getAbsolutePath());
           try {
             FileUtils.write(lockFile, "STARTED");
             SpringBootContainer.logger.info("----准备写入完成 >>>>>" + lockFile.getAbsolutePath());
           } catch (IOException e) {
             e.printStackTrace(System.err);
             SpringBootContainer.logger.error("----写入成功标记完成 >>>>>", e);
           }
 
           StopApp.RegisterStopApp(lockFile, SpringBootContainer.context, new Callable()
           {
             public Object call() throws Exception
             {
               boolean delete = lockFile.delete();
               if (delete)
               {
                 SpringBootContainer.logger.info("启动锁文件删除完成");
               }
               else lockFile.deleteOnExit();
 
               if (lockFile.exists()) {
                 String filepath = lockFile.getAbsolutePath();
                 Runtime rt = Runtime.getRuntime();
                 try {
                   rt.exec("rm -rf " + filepath);
                 } catch (IOException e) {
                   SpringBootContainer.logger.info("调用rm命令删除", e);
                 }
               }
               return null;
             }
           });
         }
         SpringBootContainer.logger.info("程序系统完成");
       }
     };
     thread.setPriority(10);
     thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler()
     {
       public void uncaughtException(Thread t, Throwable e) {
         SpringBootContainer.logger.error("启动线程判断异常>>", e);
       }
     });
     thread.start();
   }
 
   public void stop()
   {
     logger.info("spring容器被停止>>>>1111111");
     try {
       if (context != null) {
         context.stop();
         context.close();
         context = null;
       }
     } catch (Throwable e) {
       System.out.print(e.getMessage());
     }
   }
 
   private void delRestartLock() {
     String workdir = EnvUtil.getWorkDir();
     FileUtil.deleteQuietly(new File(workdir + "/bin/" + "config_restart.lock"));
   }
 
   private void runPost() {
     for (final ContainerPost containerPost : containerPostList) {
       Thread thread = new Thread(new Runnable()
       {
         public void run() {
           containerPost.doPost(SpringBootContainer.context);
         }
       });
       thread.start();
     }
   }
 
   private void runInitBefore()
   {
     for (final ContainerInitBefore containerInitBefore : containerInitBefores) {
       Thread thread = new Thread(new Runnable()
       {
         public void run() {
           containerInitBefore.doBefore();
         }
       });
       thread.start();
     }
   }
 }
