package auto.common.container;

import org.springframework.context.ApplicationContext;

public abstract interface ContainerPost
{
  public abstract void doPost(ApplicationContext paramApplicationContext);
}

