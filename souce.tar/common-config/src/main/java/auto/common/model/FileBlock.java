 package auto.common.model;
 
 import java.io.File;
 
 public class FileBlock
 {
   private File blockfile;
   private int seq_no;
   private int startPosition;
   private int endPosition;
   private int size;
   private String md5;
 
   public File getBlockfile()
   {
     return this.blockfile;
   }
 
   public void setBlockfile(File blockfile) {
     this.blockfile = blockfile;
   }
 
   public int getSeq_no() {
     return this.seq_no;
   }
 
   public void setSeq_no(int seq_no) {
     this.seq_no = seq_no;
   }
 
   public int getStartPosition() {
     return this.startPosition;
   }
 
   public void setStartPosition(int startPosition) {
     this.startPosition = startPosition;
   }
 
   public int getEndPosition() {
     return this.endPosition;
   }
 
   public void setEndPosition(int endPosition) {
     this.endPosition = endPosition;
   }
 
   public int getSize() {
     return this.size;
   }
 
   public void setSize(int size) {
     this.size = size;
   }
 
   public String getMd5() {
     return this.md5;
   }
 
   public void setMd5(String md5) {
     this.md5 = md5;
   }
 }

