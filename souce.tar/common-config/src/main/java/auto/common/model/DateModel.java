 package auto.common.model;
 
 import java.util.Date;
 
 public class DateModel
 {
   private String timeString;
   private Long utcTime;
   private String format;
   private String fromTimeZone;
   private Date date;
   private String toTimeString;
 
   public String getTimeString()
   {
     return this.timeString;
   }
 
   public void setTimeString(String timeString) {
     this.timeString = timeString;
   }
 
   public Long getUtcTime() {
     return this.utcTime;
   }
 
   public void setUtcTime(Long utcTime) {
     this.utcTime = utcTime;
   }
 
   public String getFormat() {
     return this.format;
   }
 
   public void setFormat(String format) {
     this.format = format;
   }
 
   public String getFromTimeZone() {
     return this.fromTimeZone;
   }
 
   public void setFromTimeZone(String fromTimeZone) {
     this.fromTimeZone = fromTimeZone;
   }
 
   public Date getDate() {
     return this.date;
   }
 
   public void setDate(Date date) {
     this.date = date;
   }
 
   public String getToTimeString() {
     return this.toTimeString;
   }
 
   public void setToTimeString(String toTimeString) {
     this.toTimeString = toTimeString;
   }
 }

