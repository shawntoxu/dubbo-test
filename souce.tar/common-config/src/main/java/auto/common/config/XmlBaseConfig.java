 package auto.common.config;
 
 import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
 import org.springframework.boot.autoconfigure.SpringBootApplication;
 
 @SpringBootApplication
 @EnableAutoConfiguration
 public abstract class XmlBaseConfig
 {
   public static boolean LoadXmlConfig = true;
 }


