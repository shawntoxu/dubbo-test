 package auto.common.config;
 
 import com.alibaba.dubbo.config.ApplicationConfig;
 import com.alibaba.dubbo.config.ConsumerConfig;
 import com.alibaba.dubbo.config.MonitorConfig;
 import com.alibaba.dubbo.config.ProviderConfig;
 import com.alibaba.dubbo.config.RegistryConfig;
 import com.alibaba.dubbo.config.spring.AnnotationBean;
 import auto.common.constant.Constant;
 import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
 import org.springframework.boot.autoconfigure.SpringBootApplication;
 import org.springframework.context.annotation.Bean;
 import org.springframework.util.SocketUtils;
 
 @SpringBootApplication
 @EnableAutoConfiguration
 public abstract class BaseConfig
 {
   public static boolean DEV = false;
   //扫描以此为前缀的包下的类 注册
   public static final String PACKAGE_PRE3="auto.common" ;
   @Bean
   public abstract ApplicationConfig registerApplicationConfig();
 
   @Bean
   public RegistryConfig intiRegistryConfig()
   {
     RegistryConfig registryConfig = new RegistryConfig();
     registryConfig.setProtocol("zookeeper");
     registryConfig.setAddress(Constant.ZK_ADDRESS);
     registryConfig.setGroup(getRegistryGroup());
     return registryConfig;
   }
 
   public String getRegistryGroup() {
     return "dubbo";
   }
 
   @Bean
   public MonitorConfig monitorConfig() {
     MonitorConfig monitorConfig = new MonitorConfig();
     if (!DEV) {
       monitorConfig.setProtocol("registry");
     }
     return monitorConfig;
   }
 
   @Bean
   public ProviderConfig initProtocolConfig() {
     ProviderConfig providerConfig = new ProviderConfig();
     if (DEV)
       providerConfig.setProtocol("injvm");
     else {
       providerConfig.setProtocol("hessian");
     }
     providerConfig.setPort(Integer.valueOf(SocketUtils.findAvailableTcpPort(16000, 18000)));
     
     providerConfig.setLoadbalance("random");
     providerConfig.setThreads(Integer.valueOf(1000));
     providerConfig.setAccepts(Integer.valueOf(30000));
     providerConfig.setServer("tomcat");
     return providerConfig;
   }
 
   @Bean
   public AnnotationBean iniAnnotationBean() {
     AnnotationBean annotationBean = new AnnotationBean();
     annotationBean.setPackage(PACKAGE_PRE3);
     return annotationBean;
   }
 
   @Bean
   public ConsumerConfig initConsumerConfig()
   {
     ConsumerConfig consumerConfig = new ConsumerConfig();
     consumerConfig.setCheck(Boolean.valueOf(false));
     consumerConfig.setTimeout(Integer.valueOf(60000));
     consumerConfig.setInjvm(Boolean.valueOf(DEV));
     return consumerConfig;
   }
 }
