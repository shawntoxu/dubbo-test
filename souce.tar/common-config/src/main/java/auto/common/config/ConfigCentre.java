 package auto.common.config;
 
 import com.alibaba.dubbo.config.ApplicationConfig;
 import com.alibaba.fastjson.JSON;
 import auto.common.constant.Constant;
 import auto.common.container.ConfigWatcher;
 import auto.common.container.SpringBootContainer;
 import auto.common.util.EnvUtil;
 import auto.common.util.FileUtil;
 import auto.common.util.StringUtil;
import auto.common.util.ZkUtils;
import auto.common.util.ZkUtils.StringSerializer;
 import java.io.ByteArrayOutputStream;
 import java.io.File;
 import java.io.IOException;
 import java.io.PrintStream;
 import java.text.ParseException;
 import java.util.ArrayList;
 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;
 import java.util.Map.Entry;
 import org.I0Itec.zkclient.IZkDataListener;
 import org.I0Itec.zkclient.ZkClient;
 import org.apache.commons.exec.CommandLine;
 import org.apache.commons.exec.DefaultExecutor;
 import org.apache.commons.exec.PumpStreamHandler;
 import org.apache.commons.io.FilenameUtils;
 import org.apache.commons.lang3.BooleanUtils;
 import org.apache.commons.lang3.math.NumberUtils;
 
 public class ConfigCentre
 {
   private static List<String> applist = new ArrayList();
   private static HashMap<String, String> configMaps = new HashMap();
   private static ConfigCentre configCentre;
   private static ZkClient client = new ZkClient(Constant.ZK_ADDRESS, 30000);
   public static SpringBootContainer springBootContainer;
   private static List<ConfigWatcher> watcherlist = new ArrayList();
   public static final String COMMON_CONFIG_ID = "common-config";
   public static final String MY_COMMON_CONFIG_ID = "my-common-config";
   
   public static final String ZK_CONFIG_ROOTNODE="/auto/common/config" ;
   
 
   private ConfigCentre()
     throws Exception
   {
     client.setZkSerializer(new ZkUtils.StringSerializer("UTF-8"));
     List configs = client.getChildren(ZK_CONFIG_ROOTNODE);
     if (BaseConfig.DEV) {
       System.out.println("Is DEV Model,Use 'application.id.dev' on 'application.properties' ");
       List devapplist = PropertiesRead.loadApplicationProperties(applist);
       getConifgByZooKeeper(configs, devapplist);
     } else {
       System.out.println("Is PRODUCTION Model,Use 'application.id' on 'Application.Class registerApplicationConfig getName' ");
       getConifgByZooKeeper(configs, applist);
     }
   }
 
   private static synchronized ConfigCentre getConfigCentre()
   {
     try {
       return new ConfigCentre();
     } catch (Exception e) {
       e.printStackTrace();
     }
     return null;
   }
 
   private void getConifgByZooKeeper(List<String> configs, List<String> applist) throws ParseException {
     for (String appid : applist)
       if (configs.contains(appid)) {
         String configstr = (String)client.readData(ZK_CONFIG_ROOTNODE+"/" + appid);
         System.out.println("Get '" + appid + "' Config String By ZooKeeper is :" + configstr);
         Map<String,String> configmap = (Map)JSON.parse(configstr);
         for (Map.Entry entry : configmap.entrySet()) {
           configMaps.put(((String)entry.getKey()).trim(), ((String)entry.getValue()).trim());
         }
         addConfigChangeEvent(appid);
       } else {
         System.err.println("ZooKeeper Path Nothingness AppId " + appid + ",Pleasea Check Config Centre Or 'application.properties'!!!");
       }
   }
 
   private void addConfigChangeEvent(String appid)
   {
     client.subscribeDataChanges(ZK_CONFIG_ROOTNODE + "/" + appid, new ConfigListenerAdapter(null));
   }
 
   public static void RegisterAppIds(Class<?>[] sources) {
     for (Class source : sources) {
       try {
         Object object = Class.forName(source.getName()).newInstance();
         if ((object instanceof BaseConfig)) {
           BaseConfig config = (BaseConfig)object;
           applist.add(config.registerApplicationConfig().getName());
         } else if (object.getClass().getSimpleName().equals("CommonBeanApplication")) {
           applist.add("common-config");
         } else if (object.getClass().getSimpleName().equals("MyCommonBeanApplication")) {
           applist.add("my-common-config");
         } else {
           applist.add(object.getClass().getSimpleName());
         }
       }
       catch (Exception e) {
         e.printStackTrace();
       }
     }
     setSystemProperty();
   }
 
   public static String getString(String key) {
     String systemProperty = System.getProperty(key);
     if (StringUtil.isNotEmpty(systemProperty)) return systemProperty;
     if (configCentre == null)
       configCentre = getConfigCentre();
     return (String)configMaps.get(key);
   }
 
   public static Integer getInteger(String key) {
     return Integer.valueOf(NumberUtils.toInt(getString(key)));
   }
 
   public static Long getLong(String key) {
     return Long.valueOf(NumberUtils.toLong(getString(key)));
   }
 
   public static Boolean getBoolean(String key) {
     return Boolean.valueOf(BooleanUtils.toBoolean(getString(key)));
   }
 
   public static String getString(String key, String defaultValue) {
     String systemProperty = System.getProperty(key);
     if (StringUtil.isNotEmpty(systemProperty)) return systemProperty;
     if (configCentre == null)
       configCentre = getConfigCentre();
     String value = (String)configMaps.get(key);
     return StringUtil.isNotEmpty(value) ? value : defaultValue;
   }
 
   public static Integer getInteger(String key, Integer defaultValue) {
     return Integer.valueOf(NumberUtils.toInt(getString(key), defaultValue.intValue()));
   }
 
   public static Long getLong(String key, Long defaultValue) {
     return Long.valueOf(NumberUtils.toLong(getString(key), defaultValue.longValue()));
   }
 
   public static Boolean getBoolean(String key, Boolean defaultValue) {
     String value = getString(key);
     if (StringUtil.isNotEmpty(value)) {
       return Boolean.valueOf(BooleanUtils.toBoolean(getString(key)));
     }
     return defaultValue;
   }
 
   public static void addWatcher(ConfigWatcher configWatcher)
   {
     watcherlist.add(configWatcher);
   }
 
   private static void setSystemProperty()
   {
     configCentre = getConfigCentre();
     for (Map.Entry entry : configMaps.entrySet())
       System.setProperty((String)entry.getKey(), (String)entry.getValue()); 
   }
   private class ConfigListenerAdapter implements IZkDataListener {
     private ConfigListenerAdapter(Object object) {
     }
 
     public void handleDataChange(String s, Object obj) throws Exception { String configstr = (String)obj;
       System.out.println("Application " + s + " Config Changeing,Event Data is:" + configstr);
       restartAppForConfigChange(configstr, FilenameUtils.getBaseName(s)); }
 
     public void handleDataDeleted(String s) throws Exception
     {
       System.out.println("Application " + s + " Config Delete!!!");
     }
 
     private void restartAppForConfigChange(String configstr, String appId) throws IOException {
       Map<String,String> changemap = (Map)JSON.parse(configstr);
       boolean changeflag = false;
       if (changemap != null) {
         for (Map.Entry entry : changemap.entrySet()) {
           String oldvalue = (String)ConfigCentre.configMaps.get(entry.getKey());
           String newvalue = (String)entry.getValue();
           if ((StringUtil.isEmpty(oldvalue)) || (!newvalue.equals(oldvalue))) {
             System.out.println("Config Change ,Key=" + (String)entry.getKey() + ",old Value=" + oldvalue + ",new Value=" + newvalue);
             ConfigCentre.configMaps.put((String) entry.getKey(), newvalue);
             System.setProperty((String)entry.getKey(), (String)entry.getValue());
             changeflag = true;
           }
         }
 
       }
 
       if (changeflag)
         for (ConfigWatcher watcher : ConfigCentre.watcherlist)
           watcher.notification(ConfigCentre.springBootContainer.getContext(), appId, changemap);
     }
 
     private void restartApp(String configstr)
       throws IOException
     {
       if (EnvUtil.isUnix()) {
         String workdir = EnvUtil.getWorkDir();
         writeRestartFile(workdir, configstr);
         String restartScript = "sh " + workdir + "/bin/stop.sh";
         System.out.println("----------------------------------------------------------------------");
         System.out.println("Listener ConfigCentre Config Change ,Exec Restart Script:" + restartScript);
         System.out.println("----------------------------------------------------------------------");
         ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
         ByteArrayOutputStream errorStream = new ByteArrayOutputStream();
         CommandLine cmdLine = CommandLine.parse(restartScript);
         DefaultExecutor executor = new DefaultExecutor();
         executor.setExitValues(null);
         PumpStreamHandler streamHandler = new PumpStreamHandler(outputStream, errorStream);
         executor.setStreamHandler(streamHandler);
         executor.execute(cmdLine);
         System.out.println(outputStream.toString("utf-8"));
         System.out.println(errorStream.toString("utf-8"));
       } else {
         System.out.println("----------------------------------------------------------------------");
         System.out.println("OS is Windows ,Sorry No Restart Script,Jvm Exit,Please Manual Start!");
         System.out.println("----------------------------------------------------------------------");
       }
     }
 
     private void writeRestartFile(String workdir, String configstr)
       throws IOException
     {
       File lockfile = new File(workdir + "/bin/" + "config_restart.lock");
       FileUtil.WriteContentToFile(lockfile, configstr);
     }
   }
 }


