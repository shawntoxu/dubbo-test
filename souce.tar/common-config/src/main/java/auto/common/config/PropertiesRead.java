 package auto.common.config;
 
 import auto.common.util.EnvUtil;
 import auto.common.util.StringUtil;
 import java.io.File;
 import java.io.FileInputStream;
 import java.io.IOException;
 import java.io.InputStream;
 import java.io.PrintStream;
 import java.util.ArrayList;
 import java.util.List;
 import java.util.Properties;
 
 public class PropertiesRead
 {
   private static final String APP_PROPERTIES = "application.properties";
   private static final String APP_DEV_ID = "application.id.dev";
 
   static List<String> loadApplicationProperties(List<String> appIds)
   {
     InputStream is = null;
     List devAppIds = new ArrayList();
     try {
       for (String appId : appIds) {
         File configfile = new File(getConfigFile(appId));
         if (!configfile.exists()) {
           System.err.println(configfile + " Not Exists,Can not Read Config,User DEFAULT APPID " + appId);
         }
         else {
           is = new FileInputStream(configfile);
           Properties prop = new Properties();
           prop.load(is);
           String devappid = prop.getProperty("application.id.dev");
           if (StringUtil.isNotEmpty(devappid)) {
             devAppIds.add(devappid);
           } else {
             System.err.println(configfile + " Is Empty,User DEFAULT APPID " + appId);
             devAppIds.add(appId);
           }
 
         }
 
       }
 
     }
     catch (IOException e)
     {
       e.printStackTrace();
     } finally {
       try {
         if (is != null)
           is.close();
       }
       catch (Exception e) {
         System.err.println("close config file error!" + e.getMessage());
       }
     }
 
     return devAppIds;
   }
 
   private static String getConfigFile(String appid) {
     String config_home = System.getenv("CONFIG_HOME");
     if (StringUtil.isEmpty(config_home)) {
       System.err.println("DEV MODEL Read EVN VAR 'CONFIG_HOME' IS NULL,USE HOME " + EnvUtil.getUserHome());
       config_home = EnvUtil.getUserHome();
     }
     return config_home + "/" + appid + "." + "application.properties";
   }
 }


