package auto.common.test.cus;


import com.alibaba.dubbo.container.Main;

import auto.common.config.BaseConfig;
import auto.common.config.XmlBaseConfig;
import auto.common.container.SpringBootContainer;

public class TestCustomerRunMain {
	
	public static void main(String[] args) {
		BaseConfig.DEV = true;
		XmlBaseConfig.LoadXmlConfig = false;
		SpringBootContainer.containerPostList.add(applicationContext -> {

		});
		String[] argsparams = { "springboot" };
		Main.main(argsparams);
		System.out.print("start TestCustormer down");
	}


}
