package auto.common.test.cus;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.dubbo.config.ApplicationConfig;

import auto.common.config.BaseConfig;
import auto.common.config.ConfigCentre;

public class TestCustomerApp extends BaseConfig {

	 protected final Log logger = LogFactory.getLog(TestCustomerApp.class);
	public static final String APP_REGISTRY_NAME="TEST_CUSTORMER-1";
	public static final String DUBBO_REGISTER_GROUP="TEST_GROUP";

	
    @Override
    public ApplicationConfig registerApplicationConfig() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(APP_REGISTRY_NAME);
    	//test get config
    	getConfig();
        return applicationConfig;
    }

    @Override
    public String getRegistryGroup() {
    	
        return DUBBO_REGISTER_GROUP ;
    }
	
    
    private String getConfig(){
    	
    	logger.info( "GET_KEY :test " + ConfigCentre.getString("test"));
    	
    	return null  ;
    }
	
}
