package auto.common.cusimpl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSON;
import com.alibaba.dubbo.config.annotation.Reference;

import auto.common.testapi.UserService;
import auto.common.testapi.param.UserParam;

@RequestMapping("/test")
@Controller
@EnableAutoConfiguration
public class TestCustomer {
	
	@Reference   //use  productor  service 
	private UserService  userService ; 
	
	@RequestMapping(value = "userlist")
	@ResponseBody
	public String TestCustormer(){
		return  userService.getUserList().toString() ; 
	}
	
	//模拟form 提交 ：  curl 'http://172.30.80.38:8080/test/userupdate' -H 'Origin: chrome-extension://aejoelaoggembcahagimdiliamlcdmfm' -H 'Accept-Encoding: gzip, deflate' -H 'Accept-Language: zh-CN,zh;q=0.8' -H 'User-Agent: Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36' -H 'Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryxHwTI1J7a909DcPs' -H 'Accept: */*' -H 'Connection: keep-alive' --data-binary $'------WebKitFormBoundaryxHwTI1J7a909DcPs\r\nContent-Disposition: form-data; name="param"\r\n\r\n{"id":1,"username":"testUpdate"}\r\n------WebKitFormBoundaryxHwTI1J7a909DcPs--\r\n' --compressed
	/*
	 *
	 * @param request
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "userupdate")
	@ResponseBody
	public int UpateUser(HttpServletRequest request,@RequestParam(value = "param") String param ){
		UserParam  up = JSON.parseObject(param,UserParam.class);
		return  userService.UpdateUser(up) ;
	}
	
	
	
}
