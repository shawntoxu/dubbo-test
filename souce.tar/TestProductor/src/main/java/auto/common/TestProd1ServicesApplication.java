package auto.common;

import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.dubbo.config.ApplicationConfig;

import auto.common.config.BaseConfig;
import auto.common.config.ConfigCentre;
import auto.common.constant.DbConst;

public class TestProd1ServicesApplication  extends BaseConfig {


	 protected final Log logger = LogFactory.getLog(TestProd1ServicesApplication.class);
	public static final String APP_REGISTRY_NAME="TEST_PROD-1";
	public static final String DUBBO_REGISTER_GROUP="TEST_GROUP";

	
    @Override
    public ApplicationConfig registerApplicationConfig() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(APP_REGISTRY_NAME);
     	//test get config
    	getConfig();
        return applicationConfig;
    }

    @Override
    public String getRegistryGroup() {
        return DUBBO_REGISTER_GROUP ;
    }
    

    
	private DruidDataSource dataWriteSource() throws SQLException {
		DruidDataSource dataSource = new DruidDataSource();
		dataSource.setUrl(ConfigCentre.getString(DbConst.MYSQL_WRITE_URL));
		dataSource.setUsername(ConfigCentre.getString(DbConst.MYSQL_WRITE_USERNAME));
		dataSource.setPassword(ConfigCentre.getString(DbConst.MYSQL_WRITE_PASSWORD));

		dataSource.setMaxPoolPreparedStatementPerConnectionSize(
				ConfigCentre.getInteger(DbConst.DRUID_DATASOURCE_MAXPOOLPREPAREDSTATEMENTPERCONNECTIONSIZE));
		dataSource.setInitialSize(ConfigCentre.getInteger(DbConst.DRUID_DATASOURCE_INITIALSIZE));
		dataSource.setMinIdle(ConfigCentre.getInteger(DbConst.DRUID_DATASOURCE_MINIDLE));
		dataSource.setMaxActive(ConfigCentre.getInteger(DbConst.DRUID_DATASOURCE_MAXACTIVE));
		dataSource.setMaxWait(ConfigCentre.getLong(DbConst.DRUID_DATASOURCE_MAXWAIT));

		dataSource.setDriverClassName(DbConst.MYSQL_DRIVER);
		dataSource.setTestOnBorrow(DbConst.DRUID_TESTONBORROW);
		dataSource.setTestOnReturn(DbConst.DRUID_TESTONRETURN);
		dataSource.setTestWhileIdle(DbConst.DRUID_TESTWHILEIDLE);
		dataSource.setValidationQuery(DbConst.DRUID_VALIDATIONQUERY);
		dataSource.setTimeBetweenEvictionRunsMillis(DbConst.DRUID_TIMEBETWEENEVICTIONRUNSMILLIS);
		dataSource.setMinEvictableIdleTimeMillis(DbConst.DRUID_MINEVICTABLEIDLETIMEMILLIS);
		dataSource.setPoolPreparedStatements(DbConst.DRUID_POOLPREPAREDSTATEMENTS);
		dataSource.setFilters(DbConst.DRUID_FILTERS);
		// dataSource.setDefaultAutoCommit(false);
		dataSource.init();
		return dataSource;
	}
    
	@Bean(name = "jdbcWriteTemplate")
	public JdbcTemplate jdbcWriteTemplate() throws Exception {
		return new JdbcTemplate(dataWriteSource());
	}

	
    private String getConfig(){
    	
    	// zknode : /auto/common/config/TEST_PROD-1  “{"db_host":"172.30.80.38"}”
    	logger.info( "GET_KEY :TEST_PROD-1 " + ConfigCentre.getString("mysql.write.url"));
    	logger.info( "GET_KEY :TEST_PROD-1 " + ConfigCentre.getString(DbConst.MYSQL_WRITE_USERNAME));
    	logger.info( "GET_KEY :TEST_PROD-1 " + ConfigCentre.getString(DbConst.MYSQL_WRITE_PASSWORD));

    	
    	return null  ;
    }
	
	
	
}
