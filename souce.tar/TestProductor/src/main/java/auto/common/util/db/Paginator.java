package auto.common.util.db;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Created by Rock on 2017/5/9.
 */
@Setter
@Getter
@NoArgsConstructor
public class Paginator implements Serializable {
    public Integer getCPage() {
		return cPage;
	}

	public void setCPage(Integer cPage) {
		this.cPage = cPage;
	}

	public Integer getPSize() {
		return pSize;
	}

	public void setPSize(Integer pSize) {
		this.pSize = pSize;
	}

	public Integer getTPage() {
		return tPage;
	}

	public void setTPage(Integer tPage) {
		this.tPage = tPage;
	}

	public Integer getTSize() {
		return tSize;
	}

	public void setTSize(Integer tSize) {
		this.tSize = tSize;
	}

	/**
     * 当前页
     */
    private Integer cPage = 1;
    /**
     * 每页数量
     */
    private Integer pSize = 20;
    /**
     * 总页数
     */
    private Integer tPage = 0;
    /**
     * 总数量
     */
    private Integer tSize = 0;

    public int from() {
        return (this.cPage - 1) * this.pSize;
    }

    public int to() {
        return this.cPage * this.pSize;
    }
}
