package auto.common.util.db;


/**
 * Created by infi.he on 2016/2/1.
 */
public enum ColumnType {
    /**
     * 只有date 形如:2012-05-13
     */
    Date,

    /**
     * 数据库保存的是date类型，但是实体类接受的是long，rs.getDate("").getTime();
     */
    Date2Long,

    /**
     * 时间 形如：2012-05-13 22:10:11
     */
    Time,

    Int,

    Long,

    Double,

    Boolean,

    /**
     * 字符串形式
     *
     */
    Varchar,

    Null;
}
