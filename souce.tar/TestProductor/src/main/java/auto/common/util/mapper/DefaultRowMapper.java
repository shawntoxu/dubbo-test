package auto.common.util.mapper;


import java.util.HashMap;
import java.util.Map;

/**
 * Created by infi.he on 2016/2/1.
 */
public abstract class DefaultRowMapper {

    static Map<Class<?>, AutoRowMapper<?>> INS = new HashMap<>();


    /**
     * 获取RowMapper对象
     *
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> AutoRowMapper<T> autoRowMapper(Class<T> clazz) {
        AutoRowMapper<?> autoRowMapper = INS.get(clazz);
        if (autoRowMapper == null) {
            autoRowMapper = new AutoRowMapper(clazz);
            INS.put(clazz, autoRowMapper);
        }
        return (AutoRowMapper<T>)autoRowMapper;
    }
}
