package auto.common.util;

public class CommonConstant {
    //鏄惁鍗曠偣鐧诲綍
    public static final String IS_SECURE_SSO = "is_secure_sso";
    public static final String MASTERKEY = "masterkey";
    public static final String FAIL = "fail";
    public static final String SUCCESS = "success";


    public static final Integer HTTP_CONNECTION_TIME_OUT = 30 * 1000;
    public static final Integer HTTP_READ_TIME_OUT = 5 * 60 * 1000;

    /**
     * 榛樿椤甸潰鏄剧ず鏉℃暟锛�10
     */
    public static final int DEFAULT_PAGE_SIZE_10 = 10;

    /**
     * 榛樿椤甸潰鏄剧ず鏉℃暟锛�15
     */
    public static final int DEFAULT_PAGE_SIZE_15 = 15;
    /**
     * 榛樿椤甸潰鏄剧ず鏉℃暟锛�20
     */
    public static final int DEFAULT_PAGE_SIZE_20 = 20;

    /**
     * 榛樿椤甸潰鏄剧ず鏉℃暟锛�100
     */
    public static final int DEFAULT_PAGE_SIZE_100 = 100;


    /**
     * set
     */
    public static final String METHOD_PREFIX_SET = "set";

    /**
     * is
     */
    public static final String METHOD_PREFIX_IS = "is";

    /**
     * get
     */
    public static final String METHOD_PREFIX_GET = "get";

    /**
     * 鏃堕棿鏍煎紡鍖�
     */
    public static final String DATE_FORMAT_YYYYMMDDHHMM = "yyyy-MM-dd HH:mm";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMATYYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSSSSS = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String DATE_FORMAT_YYYYMMDDTHHMMSSSZ = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";

    /**
     * smtp 閭欢鏈嶅姟鍣ㄩ厤缃�
     */
    public static final String MAIL_USERNAME_NAME = "mail.username.name";
    public static final String MAIL_USERNAME_PASSWORD = "mail.username.password";
    public static final String MAIL_USERNAME_FROM = "mail.username.from";
    public static final String MAIL_SMTP_SERVER = "mail.smtp.server";
    public static final String MAIL_SMTP_PORT = "mail.smtp.port";

    /**
     *  1688 api constants
     */
    public static final String ALI_CDN_DOMAIN = "https://cbu01.alicdn.com/";
    public static final String ALI_API_APP_KEY = "1317354";
    public static final String ALI_API_APP_SECRET = "Den1FKI9k5Xk";
    public static final String ALI_API_SERVER_HOST = "gw.open.1688.com";
    public static final String ALI_API_REFRESH_TOKEN_URL = "https://" + ALI_API_SERVER_HOST + "/openapi/param2/1/system.oauth2/postponeToken/" + ALI_API_APP_KEY;

}
