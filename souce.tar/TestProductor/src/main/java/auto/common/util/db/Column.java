package auto.common.util.db;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by infi.he on 2016/2/1.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(value = ElementType.FIELD)
public @interface Column {
    /**
     * 对应的数据库表名
     *
     * @return
     */
     String value() default "";

    /**
     * 从rs获取值，调用Set前置方法，主要对获取的值进行处理,方法的入参必须和Set方法参数一致，并且唯一。必须有返回值且不能修改值的类型
     * @return
     */
     String setPrefixMethod() default "";

    /**
     * 字段类型
     *
     * @return
     */
     ColumnType type() default ColumnType.Null;

}
