package auto.common.dao.base;


import com.alibaba.fastjson.JSON;
import com.mysql.jdbc.Statement;

import auto.common.util.CamelCaseUtils;
import auto.common.util.CommonConstant;
import auto.common.util.ReflectUtil;
import auto.common.util.SQLUtil;
import auto.common.util.db.Column;
import auto.common.util.db.Id;
import auto.common.util.db.InsertValuePair;
import auto.common.util.db.NoSave;
import auto.common.util.db.Pager;
import auto.common.util.db.Paginator;
import auto.common.util.db.Table;
import auto.common.util.mapper.AutoRowMapper;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.KeyHolder;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DaoTemplate {
    @Autowired
    private JdbcTemplateMixed jdbcTemplateMixed;
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    public JdbcTemplateMixed getJdbcTemplate() {
        return jdbcTemplateMixed;
    }

    /**
     * 查询一个字段
     *
     * @param columnName
     * @param columnValue
     * @param rowMapper
     * @param <T>
     * @return
     */
    public <T> List<T> findByProperty(String columnName, Object columnValue, AutoRowMapper<T> rowMapper) {
        Class<T> clazz = rowMapper.getClazz();
        String tableName = ReflectUtil.getTableName(clazz);
        if (StringUtils.isEmpty(tableName)) {
            throw new RuntimeException(clazz + " not found tableName");
        }
        if (columnValue == null) {
            throw new RuntimeException(" findByProperty columnValue is null");
        }
        String sql = "select * from " + tableName + " where " + columnName + " = ?";
        logger.debug(sql);
        logger.debug(columnValue.toString());
        return getJdbcTemplate().query(sql, new Object[]{columnValue}, rowMapper);
    }

    public <T> List<T> findByPropertyIn(String columnName, List values, AutoRowMapper<T> rowMapper) {
        Class<T> clazz = rowMapper.getClazz();
        String tableName = ReflectUtil.getTableName(clazz);
        if (StringUtils.isEmpty(tableName)) {
            throw new RuntimeException(clazz + " not found tableName");
        }
        if (values.isEmpty()) {
            throw new RuntimeException(" findByPropertyIn values is empty!");
        }
        String placeholder = SQLUtil.appendPlaceholder(values.size());
        String sql = "select * from " + tableName + " where " + columnName + " in (" + placeholder + ")";

        return getJdbcTemplate().query(sql, values.toArray(), rowMapper);
    }

    /**
     * 查询一个字段
     *
     * @param columnName
     * @param columnValue
     * @param rowMapper
     * @param <T>
     * @return
     */
    public <T> T findOneByProperty(String columnName, Object columnValue, AutoRowMapper<T> rowMapper) {
        List<T> list = findByProperty(columnName, columnValue, rowMapper);
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    /**
     * 获取所有的数据
     *
     * @param rowMapper
     * @param <T>
     * @return
     */
    public <T> List<T> findAll(AutoRowMapper<T> rowMapper) {
        Class<T> clazz = rowMapper.getClazz();
        String tableName = ReflectUtil.getTableName(clazz);
        if (StringUtils.isEmpty(tableName)) {
            throw new RuntimeException(clazz + " not found tableName");
        }
        String sql = "select * from " + tableName;
        return getJdbcTemplate().query(sql, rowMapper);
    }


    /**
     * 执行插入sql，返回指定的ID
     *
     * @param sql
     * @param pstAssign
     * @return
     */
    public Long saveResultId(final String sql, final PstAssign pstAssign) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        getJdbcTemplate().update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            if (pstAssign != null) {
                pstAssign.setParam(ps);
            }
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    /**
     * @return
     */
    public <T> Long saveResultId(T obj) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        getJdbcTemplate().update(con -> {
            PreparedStatement ps = null;
            Class<?> clazz = obj.getClass();
            String tableName = ReflectUtil.getTableName(clazz);
            if (StringUtils.isNoneEmpty(tableName)) {
                ps = getPreparedStatemet(tableName, obj, con);
            }
            if (ps == null)
                throw new RuntimeException("check" + obj.getClass() + " Table annotation， saveProduct failed !");
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }


    /**
     * @return
     */
    public <T> Long saveResultIdByWhere(String sql, List values) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        getJdbcTemplate().update(con -> {
            PreparedStatement ps = null;
            ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            setValues(ps, values);
            if (ps == null)
                throw new RuntimeException("save failed ! sql ==> "+sql+" | values==>" +values);
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }


    /**
     * 执行插入sql，返回指定的ID
     *
     * @param sql
     * @param pstAssign
     * @return
     */
    public void save(final String sql, final PstAssign pstAssign) {
        getJdbcTemplate().update(con -> {
            PreparedStatement ps = con.prepareStatement(sql);
            if (pstAssign != null) {
                pstAssign.setParam(ps);
            }
            return ps;
        });
    }

    protected  <T> Boolean updateById(T o) {
        Class<?> clazz = o.getClass();
        //table name
        String tableName;
        Table table = clazz.getAnnotation(Table.class);
        if (table != null) {
            tableName = table.value();
        } else {
            tableName = CamelCaseUtils.toSnakeCase(clazz.getSimpleName());
        }
        //where clause  e.g. id=XXX
        String keyName = null;
        Object keyValue = null;
        //sql with placeholder
        StringBuilder uSql = new StringBuilder().append("updateProduct " + tableName);
        //values
        List<Object> values = new ArrayList();
        boolean isFirst = true;
        for (Field field : clazz.getDeclaredFields()) {
            if (field.getName().equalsIgnoreCase("serialVersionUID")) {
                continue;
            }
            Object v = null;
            try {
                Method method = clazz.getDeclaredMethod("get" + CamelCaseUtils.upFirstChar(field.getName()));
                v = method.invoke(o);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                logger.error("reflect get field value error.", e);
            }
            if (v != null) {
                Column annotation = field.getAnnotation(Column.class);
                if (field.getAnnotation(NoSave.class) != null) {
                    continue; //不保存的字段自然不会更新
                }
                //当keyName 无效时才去获取。
                if (keyName == null) {
                    Id annId = field.getAnnotation(Id.class);
                    if (annId != null) {
                        keyName = CamelCaseUtils.toSnakeCase(field.getName());
                        keyValue = v;
                        continue;  //id 不会在set 里。
                    }
                }
                //非id ，添加到参数列表里。
                if (v.getClass().isEnum()) {
                    v = ((Enum) v).name();
                }
                values.add(v);
                String key = annotation != null ? annotation.value() : CamelCaseUtils.toSnakeCase(field.getName());
                if (isFirst) {
                    isFirst = false;
                    uSql.append(" set " + key + "= ?");
                } else {
                    uSql.append("," + key + "= ?");
                }
            }
        }
        PstAssign pstAssign = ps -> {
            for (int i = 0; i < values.size(); i++) {
                ps.setObject(i + 1, values.get(i));
            }
        };
        if (keyName == null) {
            logger.error("invalid where clause! can not found @Id.");
            return false;
        } else {
            uSql.append(" where " + keyName + "=" + keyValue);
            // 执行sql，传入参数值
            save(uSql.toString(), pstAssign);
            return true;
        }
    }

    /**
     * 批量保存，返回批量的值
     *
     * @param sql
     * @param batchPstAssign
     * @param list
     * @return
     */
    public <T> List<Long> batchSaveResultId(final String sql, final BatchPstAssign<T> batchPstAssign, final List<T> list) {
        return getJdbcTemplate().execute((ConnectionCallback<List<Long>>) conn -> {
                    final int count = list.size();
                    List<Long> ids = new ArrayList<>(count);
                    conn.setAutoCommit(false);
                    PreparedStatement ps = null;
                    ResultSet resultSet = null;
                    try {
                        ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
                        for (T t : list) {
                            batchPstAssign.setParam(ps, t);
                            ps.addBatch();
                        }
                        ps.executeBatch();
                        resultSet = ps.getGeneratedKeys();
                        while (resultSet.next()) {
                            ids.add(resultSet.getLong(1));
                        }
                        conn.commit();
                        resultSet.close();
                        return ids;
                    } catch (Exception e) {
                        conn.rollback();
                        throw e;
                    } finally {
                        JdbcUtils.closeResultSet(resultSet);
                        JdbcUtils.closeStatement(ps);
                    }
                }
        );
    }


    /**
     * 批量保存，返回批量的值
     *
     * @param list
     * @return
     */
    public <T> List<Long> batchSaveResultId(final List<T> list) {
        List<Long> result = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(list)) {
            for (T t : list) {
                result.add(saveResultId(t));
            }
        }
        return result;
    }

    public PreparedStatement getPreparedStatemet(String tableName, Object obj, Connection con) throws SQLException {
        //all fields
        List<InsertValuePair> insertValuePairList = ReflectUtil.getInsertValuePairList(obj.getClass());
        // not null values
        List<Object> values = new ArrayList<>();
        StringBuilder insertSql = new StringBuilder();
        if (insertValuePairList.size() > 0) {
            StringBuilder valueSql = new StringBuilder();
            insertSql.append(" insert into ").append(tableName).append(" ( ");
            valueSql.append(" values( ");
            for (int i = 0, len = insertValuePairList.size(); i < len; i++) {
                InsertValuePair insertValuePair = insertValuePairList.get(i);
                Object fieldValue = ReflectUtil.getFieldValue(obj, insertValuePair.getMethod(), insertValuePair.getField());
                if (fieldValue == null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Class:{},属性：{}没有值。", obj.getClass().getSimpleName(), insertValuePair.getField().getName());
                    }
                } else {
                    if (fieldValue instanceof  Enum) {
                        fieldValue = ((Enum) fieldValue).name();
                    }
                    values.add(fieldValue);
                    String dbColumnName = insertValuePair.getColumnName();
                    insertSql.append(dbColumnName).append(",");
                    valueSql.append("?,");
                }
            }
            insertSql.deleteCharAt(insertSql.length() - 1);
            valueSql.deleteCharAt(valueSql.length() - 1);
            insertSql.append(")").append(valueSql).append(")");
            logger.debug("insertSql >>>> " + insertSql.toString());
        }
        PreparedStatement ps = con.prepareStatement(insertSql.toString(), Statement.RETURN_GENERATED_KEYS);
        setValues(ps, values);
        return ps;
    }

    private void setValues(PreparedStatement ps, List<Object> values) throws SQLException {
        for (int i = 0; i < values.size(); i++) {
            ps.setObject(i + 1, values.get(i));
        }
    }

    public static void main(String[] args) {
        System.out.println((0/5)+ (0%5 >0?1:0));
        System.out.println();
    }

    public Pager findPager(String sql, Object[] params,Integer page,Integer size, RowMapper rowMapper) {

        int sizeNo = page == null ? CommonConstant.DEFAULT_PAGE_SIZE_20 : size == null ? CommonConstant.DEFAULT_PAGE_SIZE_20 : size;
        int firstResult = page == null ? 0 : (page - 1) * sizeNo;

        logger.info("sql >>>> " + sql);
        logger.info("params >>>>> " + JSON.toJSONString(params));
        logger.info(" firstResult >>>> " + firstResult);
        logger.info(" sizeNo >>>> " + sizeNo);
        Pager pager = new Pager();
        StringBuilder countSql = new StringBuilder("select count(1) cnt from (");
        countSql.append(sql);
        countSql.append(") as pagertable");
        Paginator paginator = new Paginator();
        if(page == null) {
            paginator.setCPage(0);
        } else {
            paginator.setCPage(page);
        }
        if(size == null) {
            paginator.setPSize(CommonConstant.DEFAULT_PAGE_SIZE_20);
        } else {
            paginator.setPSize(size);
        }
        Object count = null;
        if (params == null || params.length == 0) {
            count = getJdbcTemplate().queryForMap(countSql.toString()).get("cnt");
            logger.info("总数 >>>> " + count.toString());

            sql = sql + " LIMIT ?,?";
            Object[] selectParams = new Object[]{firstResult, sizeNo};
            logger.info("sql >>> " + sql);
            logger.info("param >>> " + JSON.toJSONString(selectParams));
            pager.setResultList(getJdbcTemplate().query(sql, selectParams, rowMapper));
        } else {
            count = getJdbcTemplate().queryForMap(countSql.toString(), params).get("cnt");
            logger.info("总数 >>>> " + count.toString());

            sql = sql + " LIMIT ?,?";
            Object[] selectParams = new Object[params.length + 2];
            for (int i = 0; i < params.length; i++) {
                selectParams[i] = params[i];
            }
            selectParams[params.length] = firstResult;
            selectParams[params.length + 1] = sizeNo;
            logger.info("sql >>> " + sql);
            logger.info("param >>> " + JSON.toJSONString(selectParams));
            pager.setResultList(getJdbcTemplate().query(sql, selectParams, rowMapper));
        }
        int tcount = Integer.valueOf(count.toString());
        int tpage = 0;
        if(size != null) {
            tpage = (tcount/size) + (tcount%size>0?1:0);
        } else {
            tpage = (tcount/CommonConstant.DEFAULT_PAGE_SIZE_20) + (tcount%CommonConstant.DEFAULT_PAGE_SIZE_20>0?1:0);
        }
        paginator.setTPage(tpage);
        paginator.setTSize(tcount);
        pager.setPaginator(paginator);
        return pager;
    }

    public void executeSql(String sql) {
        getJdbcTemplate().execute(sql);
    }

    public <T> T findOne(String sql, Object[] params, AutoRowMapper<T> rowMapper) {
        List<T> list;
        if (params != null) {
            list = getJdbcTemplate().query(sql, params, rowMapper);
        } else {
            list = getJdbcTemplate().query(sql, rowMapper);
        }

        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }
    public <T> List<T>  find(String sql, Object[] params, AutoRowMapper<T> rowMapper) {
        List<T> list;
        if (params != null) {
            list = getJdbcTemplate().query(sql, params, rowMapper);
        } else {
            list = getJdbcTemplate().query(sql, rowMapper);
        }
        return list;
    }
    
    public List<Map<String,Object>>  find(String sql, Object[] params) {
    	List<Map<String,Object>> list;
        if (params != null) {
            list = getJdbcTemplate().queryForList(sql, params);
        } else {
            list = getJdbcTemplate().queryForList(sql);
        }
        return list;
    }

    public <T> T findOneDefault(String sql, Object[] params, RowMapper<T> rowMapper) {
        List<T> list;
        if (params != null) {
            list = getJdbcTemplate().query(sql, params, rowMapper);
        } else {
            list = getJdbcTemplate().query(sql, rowMapper);
        }

        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }
}
