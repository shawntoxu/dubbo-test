package auto.common.dao.base;


import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface BatchPstAssign<T> {
    void setParam(PreparedStatement ps, T t) throws SQLException;
}
