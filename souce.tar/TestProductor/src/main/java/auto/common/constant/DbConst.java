package auto.common.constant;


public class DbConst {
	final public static String MYSQL_READ_URL = "mysql.read.url";
    final public static String MYSQL_READ_USERNAME = "mysql.read.username";
    final public static String MYSQL_READ_PASSWORD = "mysql.read.password";
    final public static String MYSQL_WRITE_URL = "mysql.write.url";
    final public static String MYSQL_WRITE_USERNAME = "mysql.write.username";
    final public static String MYSQL_WRITE_PASSWORD = "mysql.write.password";
    final public static String DRUID_DATASOURCE_MAXPOOLPREPAREDSTATEMENTPERCONNECTIONSIZE = "druid.maxPoolPreparedStatementPerConnectionSize";
    final public static String DRUID_DATASOURCE_INITIALSIZE = "druid.initialSize";
    final public static String DRUID_DATASOURCE_MINIDLE = "druid.minIdle";
    final public static String DRUID_DATASOURCE_MAXACTIVE = "druid.maxActive";
    final public static String DRUID_DATASOURCE_MAXWAIT = "druid.maxWait";
    
    public static final String MYSQL_DRIVER="com.mysql.jdbc.Driver";
    public static final boolean DRUID_TESTONBORROW=true;
    public static final boolean DRUID_TESTONRETURN=true;
    public static final boolean DRUID_TESTWHILEIDLE=true;
    public static final String DRUID_VALIDATIONQUERY="SELECT 1";
    public static final long DRUID_TIMEBETWEENEVICTIONRUNSMILLIS=1800000;
    public static final long DRUID_MINEVICTABLEIDLETIMEMILLIS=1800000;
    public static final boolean DRUID_POOLPREPAREDSTATEMENTS=true;
    public static final String DRUID_FILTERS="stat";
    
    public static final String SELECT = " select ";
    public static final String FROM = " from ";
    public static final String WHERE = " where ";
}
