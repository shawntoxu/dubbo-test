package auto.common.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.dubbo.config.annotation.Service;

import auto.common.dao.base.DaoTemplate;
import auto.common.model.User;
import auto.common.testapi.UserService;
import auto.common.testapi.param.UserParam;
import auto.common.util.mapper.DefaultRowMapper;

@Service
public class UseServiceImpl extends DaoTemplate implements UserService {

	@Override
	public List<String> getUserList() {
		// TODO Auto-generated method stub
		
		String sql = "select * from e_user" ;
		Object[] objects = null  ;
		
		 List<User> uu = getJdbcTemplate().query(sql, objects, DefaultRowMapper.autoRowMapper(User.class)) ;
		
//		List<String>  u = new ArrayList<>();
//		u.add("test-user1");
//		u.add("test-user2");
//		u.add("test-user3");
		 
		 List<String> u = new ArrayList<>();
		 for (User user : uu) {
			u.add(user.toString()) ;
		}
		
		return u.size() > 0 ? u:null;
	}

	@Override
	public Integer UpdateUser(UserParam u) {
		StringBuffer  sb  = new StringBuffer("update  e_user set ") ; 
        List<String> updateSql = new ArrayList<>();

		String sql = "";
		List plist = new ArrayList<>() ; 
		if(u.getMail() != null ){
			updateSql.add(" mail = ? ");
			plist.add(u.getMail());
		}
		
	    if(u.getUsername() != null){
	    	updateSql.add(" username =  ? ") ; 
	    	plist.add(u.getUsername());
	    }
		
	    plist.add(u.getId()) ;
	     
	     for (int i1 = 0; i1 < updateSql.size(); i1++) {
	            if (i1 + 1 == updateSql.size()) {
	                sb.append(updateSql.get(i1));
	            } else {
	                sb.append(updateSql.get(i1)).append(" , ");
	            }
	     }
		sb.append(" WHERE 1=1 AND id = ?");
		
		
		int  t  = getJdbcTemplate().update(sb.toString(), plist.toArray()) ;
		
		return t;
	     
	}

}
